void archivoEscrituraUsuarios(){
	struct Usuario *aux = primer_usuario;
	arch=fopen("usuarios.txt","w");
	if(arch==NULL){
		printf("No se encontro el archivo");
		exit(1);
	}
	else{
		while(aux!=NULL){
			fprintf(arch,"%d\t",aux->idUser);
			fprintf(arch,"%s\t",aux->perfil);
			fprintf(arch,"%d\t",aux->status);
			fprintf(arch,"%s\t",aux->password);
			fprintf(arch,"%s\t",aux->nombre);
			fprintf(arch,"%s\t",aux->apellido);
			fprintf(arch,"%d\t",aux->edad);
			fprintf(arch,"%c\n",aux->sexo);
			aux=aux->sig;
		}
		fclose(arch);
	}
}

void archivoEscrituraRutas(){
	struct Rutas *aux = primera_ruta;
	arch=fopen("rutas.txt","w");
	if(arch==NULL){
		printf("No se encontro el archivo");
		exit(1);
	}
	else{
		while(aux!=NULL){
			fprintf(arch,"%d\t",aux->numRuta);
			fprintf(arch,"%d\t",aux->statusruta);
			fprintf(arch,"%s\t",aux->origen);
			fprintf(arch,"%s\t",aux->destino);
			fprintf(arch,"%d\t",aux->horaEntrada);
			fprintf(arch,"%d\t",aux->horaSalida);
			fprintf(arch,"%s\n",aux->parada);
			aux=aux->sig;
		}
		fclose(arch);
	}
}

void archivoLecturaUsuarios(){
	Usuario read;
	arch=fopen("usuarios.txt","r");
	if(arch==NULL){
		printf("No se encontro el archivo");
		exit(1);
	}
	else{
		while(!feof(arch)){
			fscanf(arch,"%d\t",&read.idUser);
			fscanf(arch,"%s\t",&read.perfil);
			fscanf(arch,"%d\t",&read.status);
			fscanf(arch,"%s\t",&read.password);
			fscanf(arch,"%s\t",&read.nombre);
			fscanf(arch,"%s\t",&read.apellido);
			fscanf(arch,"%d\t",&read.edad);
			fscanf(arch,"%c\n",&read.sexo);
			
			Usuario *nuevo = new Usuario;
			
			nuevo->idUser = read.idUser;
			strcpy(nuevo->perfil, read.perfil);
			nuevo->status = read.status;
			strcpy(nuevo->password, read.password);
			strcpy(nuevo->nombre, read.nombre);
			strcpy(nuevo->apellido, read.apellido);
			nuevo->edad = read.edad;
			nuevo->sexo = read.sexo;
			nuevo->sig = NULL;
				
			if(primer_usuario == NULL){
				primer_usuario = nuevo;
				ultimo_usuario = nuevo;
			}
			else{
				ultimo_usuario->sig = nuevo;
				ultimo_usuario = nuevo;
			}
		}
		fclose(arch);
	}
}

void archivoLecturaRutas(){
	Rutas read;
	arch2=fopen("rutas.txt","r");
	if(arch2==NULL){
		printf("No se encontro el archivo");
		exit(1);
	}
	else{
		while(!feof(arch2)){
			fscanf(arch2,"%d\t",&read.numRuta);
			fscanf(arch2,"%d\t",&read.statusruta);
			fscanf(arch2,"%s\t",&read.origen);
			fscanf(arch2,"%s\t",&read.destino);
			fscanf(arch2,"%d\t",&read.horaEntrada);
			fscanf(arch2,"%d\t",&read.horaSalida);
			fscanf(arch2,"%s\n",&read.parada);
			
			Rutas *nuevo = new Rutas;
			
			nuevo->numRuta = read.numRuta;
			nuevo->statusruta = read.statusruta;
			strcpy(nuevo->origen, read.origen);
			strcpy(nuevo->destino, read.destino);
			nuevo->horaEntrada = read.horaEntrada;
			nuevo->horaSalida = read.horaSalida;
			strcpy(nuevo->parada, read.parada);
			nuevo->sig = NULL;
		
			if(primera_ruta == NULL){
				primera_ruta = nuevo;
				ultima_ruta = nuevo;
			} 
			else{
				ultima_ruta->sig = nuevo;
				ultima_ruta = nuevo;
			}
		}
		fclose(arch2);
	}
}

Usuario *registroUser() {
	Usuario *nuevo = new Usuario;
	nuevo->idUser = validaEntero("ID Usuario: ");
	cout<<"Perfil: "; //Admin o pasajero
	cin>>nuevo->perfil;
	cout<<"Estado: "; //Activo o inactivo
	cin>>nuevo->status;
	cout<<"Contrase�a: ";
	cin>>nuevo->password;
	cout<<"Nombre: ";
	cin>>nuevo->nombre;
	cout<<"Apellido: ";
	cin>>nuevo->apellido;
	cout<<"Edad: ";
	cin>>nuevo->edad;
	cout<<"Sexo: ";
	cin>>nuevo->sexo;
	nuevo->sig = NULL;
	return nuevo;
}

Rutas *registroRuta() {
	Rutas *nuevo = new Rutas;
	nuevo->numRuta = validaEntero("Numero de ruta: ");
	nuevo->statusruta = validaEntero("Status: ");
	cout<<"Origen: ";
	cin>>nuevo->origen;
	cout<<"Destino: ";
	cin>>nuevo->destino;
	cout<<"Hora de salida: ";
	cin>>nuevo->horaSalida;
	cout<<"Hora de entrada: ";
	cin>>nuevo->horaEntrada;
	cout<<"Parada: ";
	cin>>nuevo->parada;
	nuevo->sig = NULL;
	return nuevo;
}

Usuario *modif(Usuario *auxiliar){
	cout<<"Perfil: "; //Admin o pasajero
	cin>>auxiliar->perfil;
	cout<<"Estado: "; //Activo o inactivo
	cin>>auxiliar->status;
	cout<<"Contrase�a: ";
	cin>>auxiliar->password;
	cout<<"Nombre: ";
	cin>>auxiliar->nombre;
	cout<<"Apellido: ";
	cin>>auxiliar->apellido;
	cout<<"Edad: ";
	cin>>auxiliar->edad;
	cout<<"Sexo: ";
	cin>>auxiliar->sexo;
	return auxiliar;
}

Usuario *elim(Usuario *auxiliar){
	auxiliar->status = 0;
	return auxiliar;
}

Rutas *elim2(Rutas *auxiliar){
	auxiliar->statusruta = 0;
	return auxiliar;
}

Rutas *modif2(Rutas *auxiliar){
	cout<<"Origen: ";
	cin>>auxiliar->origen;
	cout<<"Destino: ";
	cin>>auxiliar->destino;
	cout<<"Hora de salida: ";
	cin>>auxiliar->horaSalida;
	cout<<"Hora de entrada: ";
	cin>>auxiliar->horaEntrada;
	cout<<"Parada: ";
	cin>>auxiliar->parada;
	return auxiliar;
}

void agregarUsuario() {
	Usuario *nuevo = registroUser();
	if(primer_usuario == NULL) {
		primer_usuario = nuevo;
		ultimo_usuario = nuevo;
	} else {
		ultimo_usuario->sig = nuevo;
		ultimo_usuario = nuevo;
	}
}

void agregarRuta() {
	Rutas *nuevo = registroRuta();
	if(primera_ruta == NULL) {
		primera_ruta = nuevo;
		ultima_ruta = nuevo;
	} else {
		ultima_ruta->sig = nuevo;
		ultima_ruta = nuevo;
	}
}

void modifUser(){
	int id;
	bool bandera = false;
	while(bandera==false){
			system("cls");
			id = validaEntero("Ingresa el ID del usuario para modificar: ");
			struct Usuario *auxiliar=primer_usuario;
			while(auxiliar != NULL and bandera!= true){
				if(auxiliar->idUser != id){
					auxiliar=auxiliar->sig;
				}
				else{
					bandera = true;
					modif(auxiliar);
				}
			}
			if(bandera==false){
				cout<<"El ID no existe"<<endl;
				getch();
			}
	}
}
void modifRuta(){
	int num;
	bool bandera = false;
	while(bandera==false){
			system("cls");
			num = validaEntero("Ingresa el num de la ruta para modificar: ");
			struct Rutas *auxiliar=primera_ruta;
			while(auxiliar != NULL and bandera!= true){
				if(auxiliar->numRuta != num){
					auxiliar=auxiliar->sig;
				}
				else{
					bandera = true;
					modif2(auxiliar);
				}
			}
			if(bandera==false){
				cout<<"El num no existe"<<endl;
				getch();
			}
	}
}
void eliminarUser(){
	int id;
	bool bandera = false;
	while(bandera==false){
			system("cls");
			id = validaEntero("Ingresa el ID del usuario para eliminar: ");
			struct Usuario *auxiliar=primer_usuario;
			while(auxiliar != NULL and bandera!= true){
				if(auxiliar->idUser != id){
					auxiliar=auxiliar->sig;
				}
				else{
					bandera = true;
					elim(auxiliar);
					cout<<"Elemento eliminado correctamente"<<endl;
					getch();
				}
			}
			if(bandera==false){
				cout<<"El ID no existe"<<endl;
				getch();
			}
	}
}
void eliminarRuta(){
	int num;
	bool bandera = false;
	while(bandera==false){
			system("cls");
			num = validaEntero("Ingresa el num de la ruta para eliminar: ");
			struct Rutas *auxiliar=primera_ruta;
			while(auxiliar != NULL and bandera!= true){
				if(auxiliar->numRuta != num){
					auxiliar=auxiliar->sig;
				}
				else{
					bandera = true;
					elim2(auxiliar);
					cout<<"Elemento eliminado correctamente"<<endl;
					getch();
				}
			}
			if(bandera==false){
				cout<<"El num no existe"<<endl;
				getch();
			}
	}
}

/*Usuario *modif(Empleado *auxiliar) {
	cout<<"Puesto: ";
	cin>>auxiliar->puesto;
	auxiliar->salario=validaFlotante("Salario: ");
	return auxiliar;
}*/

void consultarUser(){
	struct Usuario *auxiliar=primer_usuario;
	cout<<"\nMostrando la lista completa"<<endl;
	cout<<"idUser"<<setw(15);
	cout<<"Perfil"<<setw(15);
	cout<<"Status"<<setw(15);
	cout<<"Password"<<setw(15);
	cout<<"Nombre"<<setw(15);
	cout<<"Apellido"<<setw(15);
	cout<<"Edad"<<setw(15);
	cout<<"Sexo"<<endl;
	while(auxiliar!=NULL){
		cout<<auxiliar->idUser<<setw(15);
		cout<<auxiliar->perfil<<setw(15);
		cout<<auxiliar->status<<setw(15);
		cout<<auxiliar->password<<setw(15);
		cout<<auxiliar->nombre<<setw(15);
		cout<<auxiliar->apellido<<setw(15);
		cout<<auxiliar->edad<<setw(15);
		cout<<auxiliar->sexo<<endl;
		auxiliar=auxiliar->sig;
	}
	getch();
}

void consultarRuta(){
	struct Rutas *auxiliar=primera_ruta;
	cout<<"\nMostrando la lista completa"<<endl;
	cout<<"Numero"<<setw(15);
	cout<<"Status"<<setw(15);
	cout<<"Origen"<<setw(15);
	cout<<"Destino"<<setw(15);
	cout<<"Hora entrada"<<setw(15);
	cout<<"Hora salida"<<setw(15);
	cout<<"Parada"<<endl;
	while(auxiliar!=NULL){
		cout<<auxiliar->numRuta<<setw(15);
		cout<<auxiliar->statusruta<<setw(15);
		cout<<auxiliar->origen<<setw(15);
		cout<<auxiliar->destino<<setw(15);
		cout<<auxiliar->horaEntrada<<setw(15);
		cout<<auxiliar->horaSalida<<setw(15);
		cout<<auxiliar->parada<<endl;
		auxiliar=auxiliar->sig;
	}
	getch();
}

void consultarhorarios(){
	struct Rutas *auxiliar=primera_ruta;
	cout<<"Ruta"<<setw(15);
	cout<<"Hora entrada"<<setw(15);
	cout<<"Hora salida"<<endl;
	while(auxiliar!=NULL){
		cout<<auxiliar->numRuta<<setw(15);
		cout<<auxiliar->horaEntrada<<setw(15);
		cout<<auxiliar->horaSalida<<endl;
		auxiliar=auxiliar->sig;
	}
	getch();
}

void consultardestinos(){
	struct Rutas *auxiliar=primera_ruta;
	cout<<"Ruta"<<setw(15);
	cout<<"Destino"<<endl;
	while(auxiliar!=NULL){
		cout<<auxiliar->numRuta<<setw(15);
		cout<<auxiliar->destino<<endl;
		auxiliar=auxiliar->sig;
	}
	getch();
}

void consultarparadas(){
	struct Rutas *auxiliar=primera_ruta;
	cout<<"Ruta"<<setw(15);
	cout<<"Parada"<<endl;
	while(auxiliar!=NULL){
		cout<<auxiliar->numRuta<<setw(15);
		cout<<auxiliar->parada<<endl;
		auxiliar=auxiliar->sig;
	}
	getch();
}

void consultarnodos(){
	struct Usuario *auxiliar=primer_usuario;
	cout<<"\nMostrando la lista completa"<<endl;
	cout<<"Ubicacion"<<setw(15);
	cout<<"idUser"<<setw(15);
	cout<<"Perfil"<<setw(15);
	cout<<"Status"<<setw(15);
	cout<<"Password"<<setw(15);
	cout<<"Nombre"<<setw(15);
	cout<<"Apellido"<<setw(15);
	cout<<"Edad"<<setw(15);
	cout<<"Sexo"<<setw(15);
	cout<<"Siguiente"<<endl;
	while(auxiliar!=NULL){
		cout<<auxiliar<<setw(15);
		cout<<auxiliar->idUser<<setw(15);
		cout<<auxiliar->perfil<<setw(15);
		cout<<auxiliar->status<<setw(15);
		cout<<auxiliar->password<<setw(15);
		cout<<auxiliar->nombre<<setw(15);
		cout<<auxiliar->apellido<<setw(15);
		cout<<auxiliar->edad<<setw(15);
		cout<<auxiliar->sexo<<setw(15);
		cout<<auxiliar->sig<<endl;
		auxiliar=auxiliar->sig;
	}
	cout<<endl<<"Primer nodo: "<<primer_usuario;
	cout<<endl<<"Ultimo nodo: "<<ultimo_usuario<<endl;
	getch();
	
	struct Rutas *auxiliar2=primera_ruta;
	cout<<"\nMostrando la lista completa"<<endl;
	cout<<"Ubicacion"<<setw(15);
	cout<<"Numero"<<setw(15);
	cout<<"Status"<<setw(15);
	cout<<"Origen"<<setw(15);
	cout<<"Destino"<<setw(15);
	cout<<"Hora entrada"<<setw(15);
	cout<<"Hora salida"<<setw(15);
	cout<<"Parada"<<setw(15);
	cout<<"Siguiente"<<endl;
	while(auxiliar2!=NULL){
		cout<<auxiliar2<<setw(15);
		cout<<auxiliar2->numRuta<<setw(15);
		cout<<auxiliar2->statusruta<<setw(15);
		cout<<auxiliar2->origen<<setw(15);
		cout<<auxiliar2->destino<<setw(15);
		cout<<auxiliar2->horaEntrada<<setw(15);
		cout<<auxiliar2->horaSalida<<setw(15);
		cout<<auxiliar2->parada<<setw(15);
		cout<<auxiliar2->sig<<endl;
		auxiliar2=auxiliar2->sig;
	}
	cout<<endl<<"Primer nodo: "<<primera_ruta;
	cout<<endl<<"Ultimo nodo: "<<ultima_ruta<<endl;
	getch();
}

void menuAdmin() {
	int op1,op2,op3,op4,op5,pregunta1=1,pregunta2=1,pregunta3=1,pregunta4=1,sigue=1;
	do {
		system("cls");
		cout<<"Bienvenido Administrador"<<endl;
		cout<<"1- Agregar"<<endl;
		cout<<"2- Modificar"<<endl;
		cout<<"3- Eliminar"<<endl;
		cout<<"4- Consultar"<<endl;
		cout<<"0- Salir"<<endl;
		op1=validaEntero("Elige una funci�n: ");
		switch (op1) {
			case 1:
				pregunta1=1;
				while(pregunta1==1){
				system("cls");
				cout<<"1- Agregar usuario"<<endl;
				cout<<"2- Agregar ruta"<<endl;
				op2=validaEntero("Elige una funci�n: ");
					switch(op2) {
						case 1:
							sigue=1;
							system("cls");
							while(sigue==1){
							agregarUsuario();
							sigue = validaEntero("Tecla 1 para agregar otro usuario: ");
							}
							break;
						case 2:
							sigue=1;
							system("cls");
							while(sigue==1){
							agregarRuta();
							sigue = validaEntero("Tecla 1 para agregar otra ruta: ");
							}
							break;
						default:
							cout<<"La opcion ingresada es incorrecta"<<endl;
							break;	
					}
					pregunta1=validaEntero("Teclea 1 si deseas agregar algo m�s: ");
				}
				break;
			case 2:
				pregunta2=1;
				while(pregunta2==1){
				system("cls");
				cout<<"1- Modificar usuario"<<endl;
				cout<<"2- Modificar ruta"<<endl;
				op3=validaEntero("Elige una funci�n: ");
					switch(op3) {
						case 1:
							modifUser();
							break;
						case 2:
							modifRuta();
							break;
						default:
							cout<<"La opcion ingresada es incorrecta"<<endl;
							break;
					}
					pregunta2=validaEntero("Teclea 1 si deseas modificar algo m�s: ");
				}
				break;
			case 3:
				pregunta3=1;
				while(pregunta3==1){
				system("cls");
				cout<<"1- Eliminar usuario"<<endl;
				cout<<"2- Eliminar ruta"<<endl;
				op4=validaEntero("Elige una funci�n: ");
					switch(op4) {
						case 1:
							eliminarUser();
							break;
						case 2:
							eliminarRuta();
							break;
						default:
							cout<<"La opcion ingresada es incorrecta"<<endl;
							break;
					}
					pregunta3=validaEntero("Teclea 1 si deseas eliminar algo m�s: ");
				}
				break;
			case 4:
				pregunta4=1;
				while(pregunta4==1){
				system("cls");
				cout<<"1- Consultar usuarios"<<endl;
				cout<<"2- Consultar rutas"<<endl;
				cout<<"3- Consultar horarios"<<endl;
				cout<<"4- Consultar destinos"<<endl;
				cout<<"5- Consultar paradas"<<endl;
				cout<<"6- Nodos del proyecto"<<endl;
				op5=validaEntero("Elige una funci�n: ");
					switch(op5) {
						case 1:
							consultarUser();
							break;
						case 2:
							consultarRuta();
							break;
						case 3:
							consultarhorarios();
							break;
						case 4:
							consultardestinos();
							break;
						case 5:
							consultarparadas();
							break;
						case 6:
							consultarnodos();
							break;
						default:
							cout<<"La opcion ingresada es incorrecta"<<endl;
							break;
					}
					pregunta4=validaEntero("Teclea 1 si deseas consultar algo m�s: ");
				}
				break;
			case 0:
				cout<<"La sesion ha sido cerrada con exito"<<endl;
				getch();
				break;
			default:
				cout<<"La opcion ingresada es incorrecta"<<endl;
				getch();
				break;	
		}
	} 
	while(op1 != 0);
}

void menuPasajero() {
	int op1,op2,op3,op4,op5,pregunta1=1,pregunta2=1,pregunta3=1,pregunta4=1,sigue=1;
	do{
		system("cls");
		cout<<"Bienvenido Pasajero"<<endl;
		cout<<"1- Registrar horario"<<endl;
		cout<<"2- Eliminar horario"<<endl;
		cout<<"3- Modificar horario"<<endl;
		cout<<"4- Consultar horario"<<endl;
		cout<<"5- Tomar Autobus"<<endl;
		cout<<"6- Consultar rutas tomadas"<<endl;
		cout<<"7- Consultar rutas no tomadas"<<endl;
		cout<<"0- Salir"<<endl;
		op1=validaEntero("Elige una funci�n: ");
		switch (op1) {
			case 1:
				pregunta1=1;
				while(pregunta1==1){
				system("cls");
				cout<<"1- Agregar usuario"<<endl;
				cout<<"2- Agregar ruta"<<endl;
				op2=validaEntero("Elige una funci�n: ");
					switch(op2) {
						case 1:
							sigue=1;
							system("cls");
							while(sigue==1){
							agregarUsuario();
							sigue = validaEntero("Tecla 1 para agregar otro usuario: ");
							}
							break;
						case 2:
							sigue=1;
							system("cls");
							while(sigue==1){
							agregarRuta();
							sigue = validaEntero("Tecla 1 para agregar otra ruta: ");
							}
							break;
						default:
							cout<<"La opcion ingresada es incorrecta"<<endl;
							break;	
					}
					pregunta1=validaEntero("Teclea 1 si deseas agregar algo m�s: ");
				}
				break;
			case 2:
				pregunta2=1;
				while(pregunta2==1){
				system("cls");
				cout<<"1- Modificar usuario"<<endl;
				cout<<"2- Modificar ruta"<<endl;
				op3=validaEntero("Elige una funci�n: ");
					switch(op3) {
						case 1:
							modifUser();
							break;
						case 2:
							modifRuta();
							break;
						default:
							cout<<"La opcion ingresada es incorrecta"<<endl;
							break;
					}
					pregunta2=validaEntero("Teclea 1 si deseas modificar algo m�s: ");
				}
				break;
			case 3:
				pregunta3=1;
				while(pregunta3==1){
				system("cls");
				cout<<"1- Eliminar usuario"<<endl;
				cout<<"2- Eliminar ruta"<<endl;
				op4=validaEntero("Elige una funci�n: ");
					switch(op4) {
						case 1:
							eliminarUser();
							break;
						case 2:
							eliminarRuta();
							break;
						default:
							cout<<"La opcion ingresada es incorrecta"<<endl;
							break;
					}
					pregunta3=validaEntero("Teclea 1 si deseas eliminar algo m�s: ");
				}
				break;
			case 4:
				pregunta4=1;
				while(pregunta4==1){
				system("cls");
				cout<<"1- Consultar usuarios"<<endl;
				cout<<"2- Consultar rutas"<<endl;
				cout<<"3- Consultar horarios"<<endl;
				cout<<"4- Consultar destinos"<<endl;
				cout<<"5- Consultar paradas"<<endl;
				cout<<"6- Nodos del proyecto"<<endl;
				op5=validaEntero("Elige una funci�n: ");
					switch(op5) {
						case 1:
							consultarUser();
							break;
						case 2:
							consultarRuta();
							break;
						case 3:
							consultarhorarios();
							break;
						case 4:
							consultardestinos();
							break;
						case 5:
							consultarparadas();
							break;
						case 6:
							consultarnodos();
							break;
						default:
							cout<<"La opcion ingresada es incorrecta"<<endl;
							break;
					}
					pregunta4=validaEntero("Teclea 1 si deseas consultar algo m�s: ");
				}
				break;
			case 0:
				cout<<"La sesion ha sido cerrada con exito"<<endl;
				getch();
				break;
			default:
				cout<<"La opcion ingresada es incorrecta"<<endl;
				getch();
				break;	
		}
	}
	while(op1 !=0);
}

void iniciarSesion(){
	Usuario *aux = primer_usuario;
	int id;
	bool bandera=false;
	string pass;
	if(aux==NULL){
		cout<<"No hay datos, ingrese al archivo usuarios.txt y agregue datos";
		getch();
	}
	else{
		while(bandera==false){
			aux = primer_usuario;
			system("cls");
			id = validaEntero("Ingresar ID: ");
			cout<<"Contrase�a: ";
			cin>>pass;
				while (aux != NULL) {
					if (id == aux->idUser && pass == aux->password) {
						if(aux->status==1){
							bandera=true;
							if(strcmp(aux->perfil, "admin") == 0){
								menuAdmin();
								break;
							} 
							else{
								menuPasajero();
								break;
							}
						}
						else{
							bandera=false;
							break;
						}
					}
					else{
						aux=aux->sig;
					}
				}
			if(bandera==false){
				cout<<"Su contrase�a o usuario pueden ser incorrectos o su cuenta ha sido deshabilitada"<<endl;
				getch();
			}
		}
	}
}
