-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 29-10-2022 a las 14:00:24
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `proyecto_177887_177603`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE IF NOT EXISTS `alumnos` (
  `matricula` int(11) NOT NULL,
  `nombre` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `curricula` varchar(7) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`matricula`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`matricula`, `nombre`, `curricula`) VALUES
(177887, 'Flores García Yahir Gerardo', 'ITI01'),
(177603, 'Venegas Rivera Daniel Alejandro  ', 'ITI01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kardex`
--

CREATE TABLE IF NOT EXISTS `kardex` (
  `id` int(11) NOT NULL,
  `matricula` int(11) NOT NULL,
  `semestre` int(11) NOT NULL,
  `materia` varchar(75) COLLATE latin1_spanish_ci NOT NULL,
  `seccion` varchar(5) COLLATE latin1_spanish_ci NOT NULL,
  `periodo` varchar(7) COLLATE latin1_spanish_ci NOT NULL,
  `cfo` int(11) NOT NULL,
  `ext` int(11) NOT NULL,
  `reg` int(11) NOT NULL,
  `cf` int(11) NOT NULL,
  `creditos` int(11) NOT NULL,
  `status` varchar(15) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcar la base de datos para la tabla `kardex`
--

INSERT INTO `kardex` (`id`, `matricula`, `semestre`, `materia`, `seccion`, `periodo`, `cfo`, `ext`, `reg`, `cf`, `creditos`, `status`) VALUES
(1, 177603, 1, 'F?sica I', 'T01A', '20221S', 9, 0, 0, 9, 8, 'Aprobado'),
(2, 177603, 1, 'Introducci?n a la Computaci?n', 'T02D', '20213S', 10, 0, 0, 10, 8, 'Aprobado'),
(3, 177603, 1, 'CNG I Desarrollo del Pensamiento Cr?tico', 'T03D', '20213S', 10, 0, 0, 10, 7, 'Aprobado'),
(4, 177603, 1, 'Matem?ticas I', 'T04A', '20221S', 8, 0, 0, 8, 8, 'Aprobado'),
(5, 177603, 1, 'Ingl?s I', 'REV', '20213S', 0, 0, 0, 0, 8, 'Aprobado'),
(6, 177603, 1, 'Proyecto Integrador de Matem?ticas', '', '', 0, 0, 0, 0, 0, '-'),
(7, 177603, 2, 'F?sica II', 'T06B', '20223S', 0, 0, 0, 0, 0, '-'),
(8, 177603, 2, 'Programaci?n I', 'VT12', '20221S', 8, 0, 0, 8, 8, 'Aprobado'),
(9, 177603, 2, 'CNG II Comunicaci?n e Investigaci?n', 'T08A', '20221S', 10, 0, 0, 10, 7, 'Aprobado'),
(10, 177603, 2, 'Matem?ticas II', 'T09C', '20223S', 0, 0, 0, 0, 0, '-'),
(11, 177603, 2, 'Ingl?s II', 'REV', '20213S', 0, 0, 0, 0, 8, 'Aprobado'),
(12, 177603, 2, 'CNO I Programaci?n Web I', 'VT08', '20221S', 9, 0, 0, 9, 7, 'Aprobado'),
(13, 177603, 3, 'Qu?mica', '', '', 0, 0, 0, 0, 0, '-'),
(14, 177603, 3, 'Programaci?n II', 'T13C', '20223S', 0, 0, 0, 0, 0, '-'),
(15, 177603, 3, 'Ingl?s III', 'REV', '20213S', 0, 0, 0, 0, 8, 'Aprobado'),
(16, 177603, 3, 'Matem?ticas III', '', '', 0, 0, 0, 0, 0, '-'),
(17, 177603, 3, 'Matem?ticas Discretas', '', '', 0, 0, 0, 0, 0, '-'),
(18, 177603, 3, 'CNO II Programaci?n Web II', 'T15C', '20223S', 0, 0, 0, 0, 0, '-'),
(19, 177603, 4, 'Circuitos El?ctricos', '', '', 0, 0, 0, 0, 0, '-'),
(20, 177603, 4, 'CNG III Filosof?a y Valores', 'N03A', '20223S', 0, 0, 0, 0, 0, '-'),
(21, 177603, 4, 'Probabilidad y Estad?stica', '', '', 0, 0, 0, 0, 0, '-'),
(22, 177603, 4, 'Proyecto Integrador y Comprensivo I', '', '', 0, 0, 0, 0, 0, '-'),
(23, 177603, 4, 'Programaci?n III', '', '', 0, 0, 0, 0, 0, '-'),
(24, 177603, 4, 'Ingl?s IV', 'REV', '20213S', 0, 0, 0, 0, 8, 'Aprobado'),
(25, 177603, 5, 'Sistemas Operativos', '', '', 0, 0, 0, 0, 0, '-'),
(26, 177603, 5, 'Ingl?s V', 'I05W', '20213S', 9, 0, 0, 9, 8, 'Aprobado'),
(27, 177603, 5, 'Matem?ticas IV', '', '', 0, 0, 0, 0, 0, '-'),
(28, 177603, 5, 'Sistemas Digitales', '', '', 0, 0, 0, 0, 0, '-'),
(29, 177603, 5, 'An?lisis y Dise?o de Algoritmos', '', '', 0, 0, 0, 0, 0, '-'),
(30, 177603, 5, 'Curso del N?cleo Optativo III', '', '', 0, 0, 0, 0, 0, '-'),
(31, 177603, 6, 'Lenguajes de Programaci?n', '', '', 0, 0, 0, 0, 0, '-'),
(32, 177603, 6, 'Curso del N?cleo General IV: Creatividad', '', '', 0, 0, 0, 0, 0, '-'),
(33, 177603, 6, 'Ingenier?a de Software I', '', '', 0, 0, 0, 0, 0, '-'),
(34, 177603, 6, 'Arquitectura de Computadoras', '', '', 0, 0, 0, 0, 0, '-'),
(35, 177603, 6, 'Taller de Desarrollo Empresarial', '', '', 0, 0, 0, 0, 0, '-'),
(36, 177603, 6, 'Proyecto Integrador y Comprensivo II', '', '', 0, 0, 0, 0, 0, '-'),
(37, 177603, 7, 'Teor?a Computacional', '', '', 0, 0, 0, 0, 0, '-'),
(38, 177603, 7, 'Taller de Creatividad y Emprendedores', '', '', 0, 0, 0, 0, 0, '-'),
(39, 177603, 7, 'Ingenier?a de Software II', '', '', 0, 0, 0, 0, 0, '-'),
(40, 177603, 7, 'Base de Datos', '', '', 0, 0, 0, 0, 0, '-'),
(41, 177603, 7, 'Organizaci?n Computacional', '', '', 0, 0, 0, 0, 0, '-'),
(42, 177603, 7, 'Curso del N?cleo Optativo IV', '', '', 0, 0, 0, 0, 0, '-'),
(43, 177603, 8, 'Inteligencia Artificial I', '', '', 0, 0, 0, 0, 0, '-'),
(44, 177603, 8, 'Curso del N?cleo General V: Desarrollo de Competencias', '', '', 0, 0, 0, 0, 0, '-'),
(45, 177603, 8, 'Miner?a de Datos', '', '', 0, 0, 0, 0, 0, '-'),
(46, 177603, 8, 'Redes de Computadoras', '', '', 0, 0, 0, 0, 0, '-'),
(47, 177603, 8, 'Proyecto Integrador y Comprensivo III', '', '', 0, 0, 0, 0, 0, '-'),
(48, 177603, 8, 'Curso del N?cleo Optativo V', '', '', 0, 0, 0, 0, 0, '-'),
(49, 177603, 9, 'Compiladores', '', '', 0, 0, 0, 0, 0, '-'),
(50, 177603, 9, 'Residencia Profesional', '', '', 0, 0, 0, 0, 0, '-'),
(51, 177603, 9, 'Comercio Electr?nico', '', '', 0, 0, 0, 0, 0, '-'),
(52, 177603, 9, 'Sistemas Virtuales', '', '', 0, 0, 0, 0, 0, '-'),
(53, 177603, 9, 'Inteligencia Artificial II', '', '', 0, 0, 0, 0, 0, '-'),
(54, 177603, 9, 'Proyecto Profesional', '', '', 0, 0, 0, 0, 0, '-'),
(55, 177603, 9, 'Curso del N?cleo Optativo VI', '', '', 0, 0, 0, 0, 0, '-'),
(56, 177603, 30, 'Taller para Certificaci?n Office', 'T60D', '20213S', 10, 0, 0, 10, 0, 'Aprobado'),
(57, 177603, 30, 'Ingl?s KET Intro', 'REV', '20213S', 0, 0, 0, 0, 0, 'Aprobado'),
(58, 177603, 30, 'Ingl?s-FCE I', 'I07G', '20223S', 0, 0, 0, 0, 0, '-'),
(59, 177603, 30, 'Ingl?s-PET II', 'I06K', '20221S', 7, 0, 0, 7, 0, 'Aprobado'),
(60, 177603, 30, 'Introducci?n a las Matem?ticas', 'T61D', '20213S', 8, 0, 0, 8, 0, 'Aprobado'),
(61, 177603, 30, 'Introducci?n a la F?sica', 'T62D', '20213S', 9, 0, 0, 9, 0, 'Aprobado'),
(62, 177603, 30, 'Laboratorio de F?sica I', 'C09G', '20221S', 0, 0, 0, 0, 0, '-'),
(63, 177603, 30, 'Laboratorio de F?sica II', 'C10H', '20223S', 0, 0, 0, 0, 0, '-'),
(64, 177603, 30, 'Laboratorio de Programaci?n II', 'P04B', '20223S', 0, 0, 0, 0, 0, '-'),
(65, 177887, 1, 'F?sica I', 'T01A', '20221S', 8, 0, 0, 8, 8, 'Aprobado'),
(66, 177887, 1, 'Introducci?n a la Computaci?n', 'T02D', '20213S', 10, 0, 0, 10, 8, 'Aprobado'),
(67, 177887, 1, 'CNG I Desarrollo del Pensamiento Cr?tico', 'T03D', '20213S', 10, 0, 0, 10, 7, 'Aprobado'),
(68, 177887, 1, 'Matem?ticas I', 'T04A', '20221S', 9, 0, 0, 9, 8, 'Aprobado'),
(69, 177887, 1, 'Ingl?s I', 'REV', '20213S', 0, 0, 0, 0, 8, 'Aprobado'),
(70, 177887, 1, 'Proyecto Integrador de Matem?ticas', '', '', 0, 0, 0, 0, 0, '-'),
(71, 177887, 2, 'F?sica II', 'T06A', '20223S', 0, 0, 0, 0, 0, '-'),
(72, 177887, 2, 'Programaci?n I', 'VT12', '20221S', 9, 0, 0, 9, 8, 'Aprobado'),
(73, 177887, 2, 'CNG II Comunicaci?n e Investigaci?n', 'T08A', '20221S', 10, 0, 0, 10, 7, 'Aprobado'),
(74, 177887, 2, 'Matem?ticas II', 'T09A', '20223S', 0, 0, 0, 0, 0, '-'),
(75, 177887, 2, 'Ingl?s II', 'REV', '20213S', 0, 0, 0, 0, 8, 'Aprobado'),
(76, 177887, 2, 'CNO I Programaci?n Web I', 'VT08', '20221S', 9, 0, 0, 9, 7, 'Aprobado'),
(77, 177887, 3, 'Qu?mica', '', '', 0, 0, 0, 0, 0, '-'),
(78, 177887, 3, 'Programaci?n II', 'T13C', '20223S', 0, 0, 0, 0, 0, '-'),
(79, 177887, 3, 'Ingl?s III', 'REV', '20213S', 0, 0, 0, 0, 8, 'Aprobado'),
(80, 177887, 3, 'Matem?ticas III', '', '', 0, 0, 0, 0, 0, '-'),
(81, 177887, 3, 'Matem?ticas Discretas', '', '', 0, 0, 0, 0, 0, '-'),
(82, 177887, 3, 'CNO II Programaci?n Web II', 'T15C', '20223S', 0, 0, 0, 0, 0, '-'),
(83, 177887, 4, 'Circuitos El?ctricos', '', '', 0, 0, 0, 0, 0, '-'),
(84, 177887, 4, 'Curso del N?cleo General III: Filosof?a y Valores', '', '', 0, 0, 0, 0, 0, '-'),
(85, 177887, 4, 'Probabilidad y Estad?stica', '', '', 0, 0, 0, 0, 0, '-'),
(86, 177887, 4, 'Proyecto Integrador y Comprensivo I', '', '', 0, 0, 0, 0, 0, '-'),
(87, 177887, 4, 'Programaci?n III', '', '', 0, 0, 0, 0, 0, '-'),
(88, 177887, 4, 'Ingl?s IV', 'REV', '20213S', 0, 0, 0, 0, 8, 'Aprobado'),
(89, 177887, 5, 'Sistemas Operativos', '', '', 0, 0, 0, 0, 0, '-'),
(90, 177887, 5, 'Ingl?s V', 'I05W', '20213S', 9, 0, 0, 9, 8, 'Aprobado'),
(91, 177887, 5, 'Matem?ticas IV', '', '', 0, 0, 0, 0, 0, '-'),
(92, 177887, 5, 'Sistemas Digitales', '', '', 0, 0, 0, 0, 0, '-'),
(93, 177887, 5, 'An?lisis y Dise?o de Algoritmos', '', '', 0, 0, 0, 0, 0, '-'),
(94, 177887, 5, 'Curso del N?cleo Optativo III', '', '', 0, 0, 0, 0, 0, '-'),
(95, 177887, 6, 'Lenguajes de Programaci?n', '', '', 0, 0, 0, 0, 0, '-'),
(96, 177887, 6, 'Curso del N?cleo General IV: Creatividad', '', '', 0, 0, 0, 0, 0, '-'),
(97, 177887, 6, 'Ingenier?a de Software I', '', '', 0, 0, 0, 0, 0, '-'),
(98, 177887, 6, 'Arquitectura de Computadoras', '', '', 0, 0, 0, 0, 0, '-'),
(99, 177887, 6, 'Taller de Desarrollo Empresarial', '', '', 0, 0, 0, 0, 0, '-'),
(100, 177887, 6, 'Proyecto Integrador y Comprensivo II', '', '', 0, 0, 0, 0, 0, '-'),
(101, 177887, 7, 'Teor?a Computacional', '', '', 0, 0, 0, 0, 0, '-'),
(102, 177887, 7, 'Taller de Creatividad y Emprendedores', '', '', 0, 0, 0, 0, 0, '-'),
(103, 177887, 7, 'Ingenier?a de Software II', '', '', 0, 0, 0, 0, 0, '-'),
(104, 177887, 7, 'Base de Datos', '', '', 0, 0, 0, 0, 0, '-'),
(105, 177887, 7, 'Organizaci?n Computacional', '', '', 0, 0, 0, 0, 0, '-'),
(106, 177887, 7, 'Curso del N?cleo Optativo IV', '', '', 0, 0, 0, 0, 0, '-'),
(107, 177887, 8, 'Inteligencia Artificial I', '', '', 0, 0, 0, 0, 0, '-'),
(108, 177887, 8, 'Curso del N?cleo General V: Desarrollo de Competencias', '', '', 0, 0, 0, 0, 0, '-'),
(109, 177887, 8, 'Miner?a de Datos', '', '', 0, 0, 0, 0, 0, '-'),
(110, 177887, 8, 'Redes de Computadoras', '', '', 0, 0, 0, 0, 0, '-'),
(111, 177887, 8, 'Proyecto Integrador y Comprensivo III', '', '', 0, 0, 0, 0, 0, '-'),
(112, 177887, 8, 'Curso del N?cleo Optativo V', '', '', 0, 0, 0, 0, 0, '-'),
(113, 177887, 9, 'Compiladores', '', '', 0, 0, 0, 0, 0, '-'),
(114, 177887, 9, 'Residencia Profesional', '', '', 0, 0, 0, 0, 0, '-'),
(115, 177887, 9, 'Comercio Electr?nico', '', '', 0, 0, 0, 0, 0, '-'),
(116, 177887, 9, 'Sistemas Virtuales', '', '', 0, 0, 0, 0, 0, '-'),
(117, 177887, 9, 'Inteligencia Artificial II', '', '', 0, 0, 0, 0, 0, '-'),
(118, 177887, 9, 'Proyecto Profesional', '', '', 0, 0, 0, 0, 0, '-'),
(119, 177887, 9, 'Curso del N?cleo Optativo VI', '', '', 0, 0, 0, 0, 0, '-'),
(120, 177887, 30, 'Taller para Certificaci?n Office', 'T60D', '20213S', 10, 0, 0, 10, 0, 'Aprobado'),
(121, 177887, 30, 'Ingl?s KET Intro', 'REV', '20213S', 0, 0, 0, 0, 0, 'Aprobado'),
(122, 177887, 30, 'Ingl?s-FCE I', 'I07N', '20223S', 0, 0, 0, 0, 0, '-'),
(123, 177887, 30, 'Ingl?s-PET II', 'I06C', '20221S', 8, 0, 0, 8, 0, 'Aprobado'),
(124, 177887, 30, 'Introducci?n a las Matem?ticas', 'T61D', '20213S', 9, 0, 0, 9, 0, 'Aprobado'),
(125, 177887, 30, 'Introducci?n a la F?sica', 'T62D', '20213S', 9, 0, 0, 9, 0, 'Aprobado'),
(126, 177887, 30, 'Laboratorio de F?sica I', 'C09I', '20221S', 0, 0, 0, 0, 0, '-'),
(127, 177887, 30, 'Laboratorio de F?sica II', 'C10F', '20223S', 0, 0, 0, 0, 0, '-'),
(128, 177887, 30, 'Laboratorio de Programaci?n II', 'P04F', '20223S', 0, 0, 0, 0, 0, '-');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
