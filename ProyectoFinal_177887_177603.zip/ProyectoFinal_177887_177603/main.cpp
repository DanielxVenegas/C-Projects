#include "libreria.h"

int main() {
	SetConsoleCP(1252);
	SetConsoleOutputCP(1252);
	int exit=1;
	
	//Flores Garc�a Yahir Gerardo, Venegas Rivera Daniel Alejandro
	//177887, 177603
	//Programaci�n II
	//Tercer Semestre
	//PROYECTO FINAL
	
	archivoLecturaUsuarios();
	archivoLecturaRutas();
	
	do{
		iniciarSesion();
		exit = validaEntero("Presiona 1 para continuar: ");
	} 
	while (exit == 1);
	archivoEscrituraUsuarios();
	archivoEscrituraRutas();
	return 0;
}
