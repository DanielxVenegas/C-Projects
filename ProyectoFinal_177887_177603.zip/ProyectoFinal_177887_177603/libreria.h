#include <stdio.h> //FILE
#include <ctype.h> //isdigit retorno cero si no es digito
#include <stdlib.h> //malloc
#include <time.h>
#include <fstream>
#include <sstream>
#include <iomanip> //setw
#include <locale.h> //setLocale
#include <windows.h> //setConsole
#include <iostream> //cout, cin, fixed, endl
#include <conio.h>
#include <string> //string
#include <string.h> //strlen -> tama�o de cadena
#include <unistd.h>

using namespace std;

FILE* arch;
FILE* arch2;

struct Usuario{
	int idUser;
	char perfil[10]; //Administrador o pasajero
	int status; //Activo o inactivo
	char password[20];
	char nombre[20];
	char apellido[20];
	int edad;
	char sexo;
	struct Usuario *sig; //siguiente usuario
}*primer_usuario, *ultimo_usuario;

struct Rutas {
	int numRuta;
	int statusruta;
	char origen[30];
	char destino[30];
	int horaEntrada;
	int horaSalida;
	char parada[30];
	struct Rutas *sig; //siguiente ruta
}*primera_ruta, *ultima_ruta;

#include "validacion.h"
#include "funciones.h"
