#include <math.h> //Libreria de funciones matemáticas
#include <locale.h> //Funcion para establecer la localizacion
#include<stdio.h> //Libreria de entrada y salida de datos
#include<stdlib.h> //Funcion system
#include<time.h> //Libreria para variable time
#include<windows.h> //Libreria para funciones de la consola
#include<conio.h> //Funcion para getch
#include<string.h> //Libreria para funciones de cadenas
#include<ctype.h> //Libreria para validar cadenas
/*Funcion gotoxy para manipular la consola*/
void gotoxy(int x,int y) {
	HANDLE hcon;
	hcon = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD dwPos;
	dwPos.X = x;
	dwPos.Y= y;
	SetConsoleCursorPosition(hcon,dwPos); }
/*Funcion para imprimir los datos*/
void impresion(float calif[], int n) {
	for (int i=0; i<n; i++) {
		printf("%.2f\n",calif[i]); } }
/*Funcion para calcular el promedio*/
float promedio(float calif[], int n) {
	float suma=0,prom=0;
	for (int i=0; i<n; i++) {
		suma+=calif[i]; }
	prom=suma/n;
return prom; }
/*Funcion para ordenar los datos*/
void ordenar(float calif[], int n) {
	float aux;
	for (int i=0; i<n; i++) {
		for (int j=0; j<n-1; j++) {
			if (calif[j] > calif[j+1]) {
				aux = calif[j];
				calif[j] = calif[j+1];
				calif[j+1] = aux; } } } }
/*Funcion para obtener la mediana*/
float mediana(float calif[], int n) {
	int m, p, q;
	float r;
	if (n%2!=0) {
		m=((n+1)/2)-1;
	return calif[m]; }
	else {
		p=(n/2)-1;
		q=n/2;
		r=(calif[p]+calif[q])/2;
	return r; } }
/*Funcion para obtener la moda*/
float moda(float calif[],int n) {
	float mayor=0;
	float moda=0;
	for (int i=0; i<(n-1); i++) {
		int contador=0;
		for (int j=i+1; j<n; j++) {
		if (calif[i]==calif[j])
			contador++; }
	if (contador>mayor) {
		mayor=contador;
		moda=calif[i]; } }
return moda; }
/*Funcion para obtener el rango*/
float rango(float calif[],int n) {
return calif[n-1]-calif[0]; }
/*Funcion para obtener la varianza*/
float varianza(float calif[],int n,float media) {
	float v=0, dif=0;
	for (int i=0; i<n; i++) {
		dif=calif[i]-media;
		v=v+pow(dif,2); }
	return v/(n-1); }
/*Funcion para obtener la desviacion estandar*/
float desvstd(float varianza){ 
return sqrt(varianza); }
/*Funcion para obtener el coeficiente de variabilidad*/
float cofvar(float promedio, float desvstd) {
return (desvstd/promedio)*100; }
/*Programa principal*/
int main() {
	/*Declaracion de variables*/
	int n=0, opcion=0, x, y;
	float prom=0, med=0, mod=0, rang=0, var=0, ds=0, cvar=0; //Inicializacion de medidas estadisticas
	float calif[100]={0.0}; //Inicializacion de arreglo principal
	FILE *archivo, *puntero; //Apuntador a archivo
	HANDLE hd = GetStdHandle(STD_OUTPUT_HANDLE); //Establecer consola en modo grafico
	/*Datos del proyecto*/
	printf("Medidas de tendencia central y de variabilidad\n");
	printf("Programacion I\n");
	printf("Alumnos:\nEstrada Medina Monserrat 178430\nDaniel Alejandro Venegas Rivera 177603\n");
	printf("Profesor: Guillermo Garcia Haro\n");
	printf("Fecha de entrega: 27/05/2022");
	getch(); //Función que pausa la ejecución hasta ingresar una tecla
	system("cls"); //Borra la información en pantalla
	/*Pantalla de carga*/
	system("cls");
	SetConsoleTextAttribute(hd,9); //Establecer color de texto en azul claro
	gotoxy(13,7);
	printf("1. Desplegar datos");
	SetConsoleTextAttribute(hd,1); //Establecer color de texto en azul
	gotoxy(32,7);
	printf("2. Medidas de tendencia");
	SetConsoleTextAttribute(hd,7); //Establecer color de texto en blanco
	gotoxy(35,9);
	printf("Media");
	gotoxy(35,11);
	printf("Mediana");
	gotoxy(35,13);
	printf("Moda");
	SetConsoleTextAttribute(hd,9);
	gotoxy(57,7);
	printf("3. Medidas de variabilidad");
	SetConsoleTextAttribute(hd,7);
	gotoxy(61,9);
	printf("Rango");
	gotoxy(61,11);
	printf("Desviacion estandar");
	gotoxy(61,13);
	printf("Coef. de variacion");
	SetConsoleTextAttribute(hd,1);
	gotoxy(85,7);
	printf("4. Grafica");
	SetConsoleTextAttribute(hd,9);
	gotoxy(97,7);
	printf("5. Salir");
	SetConsoleTextAttribute(hd,2); //Establecer color de texto en verde
	gotoxy(33,17);
	printf("Selecciona la opcion que quieres consultar:\n");
	/*Tabla*/
	SetConsoleTextAttribute(hd,3); //Establecer color de texto en aguamarina
	x=12, y=20;
	for(int i=x;i<105;i++){ 
	gotoxy(i,y);
	printf("%c",205);} 
	
	x=12, y=6;
	for(int i=x;i<105;i++){ 
	gotoxy(i,y);
	printf("%c",205);} 
	
	x=11,y=7; 
	for(int i=y;i<20;i++){
	gotoxy(x,i);
	printf("%c",186);}
	
	x=105,y=7; 
	for(int i=y;i<20;i++){
	gotoxy(x,i);
	printf("%c",186);}
	
	gotoxy(11,20);
	printf("%c",200);
	
	gotoxy(105,20);
	printf("%c",188);
	
	gotoxy(105,6);
	printf("%c",187);
	
	gotoxy(11,6);
	printf("%c",201);
	
	SetConsoleTextAttribute(hd,9); 
	x=6, y=22;
	for(int i=x;i<111;i++){ 
	gotoxy(i,y);
	printf("%c",205);} 
	
	x=6, y=4;
	for(int i=x;i<111;i++){ 
	gotoxy(i,y);
	printf("%c",205);} 
	
	x=5,y=5; 
	for(int i=y;i<22;i++){
	gotoxy(x,i);
	printf("%c",186);}
	
	x=111,y=5; 
	for(int i=y;i<22;i++){
	gotoxy(x,i);
	printf("%c",186);}
	
	gotoxy(5,22);
	printf("%c",200);
	
	gotoxy(111,22);
	printf("%c",188);
	
	gotoxy(111,4);
	printf("%c",187);
	
	gotoxy(5,4);
	printf("%c",201);
	
	SetConsoleTextAttribute(hd,1); 
	gotoxy(1,1);
	printf("%c",201); 
	x=2,y=1; 
	for(int i=x;i<117;i++){ 
	gotoxy(i,y);
	printf("%c",205);} 
	
	x=2,y=1; 
	for(int i=x;i<46;i++){ 
	gotoxy(i,y);
	printf("%c",205);}
	 
	gotoxy(117,1);
	printf("%c",187); 
	
	x=1,y=2; 
	for(int i=y;i<26;i++){
	gotoxy(x,i);
	printf("%c",186);} 
	
	x=117,y=2;
	for(int i=y;i<26;i++){
	gotoxy(x,i);
	printf("%c",186);} 
	
	x=2, y=26;
	for(int i=x;i<117;i++){ 
	gotoxy(i,y);
	printf("%c",205);} 
	
	gotoxy(1,26);
	printf("%c",200);
	
	gotoxy(117,26);
	printf("%c",188);
	
	SetConsoleTextAttribute(hd,2);
	gotoxy(33,19);
	scanf("%d",&opcion);
	fflush(stdin);
	do {
		switch (opcion) {
		case 1:
			system("cls");
			system ("notepad Datos.txt");
			archivo = fopen ("Datos.txt","r");  //Se abre el archivo en modo lectura
			do {
				fscanf(archivo,"%f",&calif[n]); //Lee el dato y lo guarda en un arreglo
				n++;
			} while (!feof(archivo)); //Repite el ciclo hasta el fin del archivo (end of file)
			fclose (archivo); //Cierra el archivo
			SetConsoleTextAttribute(hd,5);
			printf("Datos ingresados:\n\n");
			impresion(calif,n);
			printf("\n");
			ordenar(calif,n);
			SetConsoleTextAttribute(hd,6);
			printf("Datos ordenados:\n\n");
			impresion(calif,n);
			getch();
			break;
		case 2:
			system("cls");
			system ("notepad Datos.txt");
			archivo = fopen ("Datos.txt","r");  //Se abre el archivo en modo lectura
			do {
				fscanf(archivo,"%f",&calif[n]); //Lee el dato y lo guarda en un arreglo
				n++;
			} while (!feof(archivo)); //Repite el ciclo hasta el fin del archivo (end of file)
			fclose (archivo); //Cierra el archivo
			ordenar(calif,n);
			/*Calcula las medidas de tendencia central*/
			printf("Medidas de tendencia central: \n\n");
			printf("Promedio: %.2f\n\n",promedio(calif,n));
			prom=promedio(calif,n);
			printf("\nMediana: %.2f\n",mediana(calif,n));
			med=mediana(calif,n);
			printf("\nModa: %.2f\n",moda(calif,n));
			mod=moda(calif,n);
			rang=rango(calif,n);
			var=varianza(calif,n,prom);
			ds=desvstd(var);
			cvar=cofvar(prom,ds);
			/*Guarda las variables en un archivo de texto*/
			puntero=fopen("Resultados.txt","w"); //Abre nuevo archivo (borra existente)
			fprintf(puntero,"%.2f\n",prom);
			fprintf(puntero,"%.2f\n",med);
			fprintf(puntero,"%.2f\n",mod);
			fprintf(puntero,"%.2f\n",rang);
			fprintf(puntero,"%.2f\n",var);
			fprintf(puntero,"%.2f\n",ds);
			fprintf(puntero,"%.2f\n",cvar);
			getch();
			break;
		case 3:
			system("cls");
			system ("notepad Datos.txt");
			archivo = fopen ("Datos.txt","r");  //Se abre el archivo en modo lectura
			do {
				fscanf(archivo,"%f",&calif[n]); //Lee el dato y lo guarda en un arreglo
				n++;
			} while (!feof(archivo)); //Repite el ciclo hasta el fin del archivo (end of file)
			fclose (archivo); //Cierra el archivo
			ordenar(calif,n);
			/*Calcula las medidas de variabilidad*/
			printf("Medidas de variabilidad: \n\n");
			prom=promedio(calif,n);
			med=mediana(calif,n);
			mod=moda(calif,n);
			printf("\nRango: %.2f\n",rango(calif,n));
			rang=rango(calif,n);
			printf("\nVarianza: %.2f\n",varianza(calif,n,prom));
			var=varianza(calif,n,prom);
			printf("\nDesviacion estandar: %.2f\n",desvstd(var));
			ds=desvstd(var);
			printf("\nCoeficiente de variabilidad: %.2f%c\n",cofvar(prom,ds),37);
			cvar=cofvar(prom,ds);
			/*Guarda las variables en un archivo de texto*/
			puntero=fopen("Resultados.txt","w"); //Abre nuevo archivo (borra existente)
			fprintf(puntero,"%.2f\n",prom);
			fprintf(puntero,"%.2f\n",med);
			fprintf(puntero,"%.2f\n",mod);
			fprintf(puntero,"%.2f\n",rang);
			fprintf(puntero,"%.2f\n",var);
			fprintf(puntero,"%.2f\n",ds);
			fprintf(puntero,"%.2f\n",cvar);
			getch();
			break;
		case 4:
			system("cls");
			system ("notepad Datos.txt");
			archivo = fopen ("Datos.txt","r");  //Se abre el archivo en modo lectura
			do {
				fscanf(archivo,"%f",&calif[n]); //Lee el dato y lo guarda en un arreglo
				n++;
			} while (!feof(archivo)); //Repite el ciclo hasta el fin del archivo (end of file)
			fclose (archivo); //Cierra el archivo
			ordenar(calif,n);
			SetConsoleTextAttribute(hd,3); 
			x=12, y=21;
			for(int i=x;i<105;i++){ 
			gotoxy(i,y);
			printf("%c",205);} 
			
			x=12, y=6;
			for(int i=x;i<105;i++){ 
			gotoxy(i,y);
			printf("%c",205);} 
			
			x=11,y=7; 
			for(int i=y;i<21;i++){
			gotoxy(x,i);
			printf("%c",186);}
			
			x=105,y=7; 
			for(int i=y;i<21;i++){
			gotoxy(x,i);
			printf("%c",186);}
			
			gotoxy(11,21);
			printf("%c",200);
			
			gotoxy(105,21);
			printf("%c",188);
			
			gotoxy(105,6);
			printf("%c",187);
			
			gotoxy(11,6);
			printf("%c",201);
			/*Título*/
			SetConsoleTextAttribute(hd,2);
			gotoxy(40,8);
			printf("Grafica de frecuencias:");
			/*Intervalos*/
			SetConsoleTextAttribute(hd,7);
			for (int i=10,j=0,k=10; i<20,j<100,k<=100; i++) {
				gotoxy(40,i);
				printf("%d - %d: \n",j,k);
				j+=10;
				k+=10; }
			/*Ciclo para imprimir frecuencia del primer intervalo*/
			gotoxy(50,10);
			for (int i=0; i<100; i++) {
				if (calif[i]>=0 && calif[i]<=10)
					printf("%c",254); }
			/*Ciclo para imprimir frecuencia del segundo intervalo*/
			gotoxy(50,11);
			for (int i=0; i<100; i++) {
				if (calif[i]>=10 && calif[i]<=20)
					printf("%c",254); }
			/*Ciclo para imprimir frecuencia del tercer intervalo*/
			gotoxy(50,12);
			for (int i=0; i<100; i++) {
				if (calif[i]>=20 && calif[i]<=30)
					printf("%c",254); }
			/*Ciclo para imprimir frecuencia del cuarto intervalo*/
			gotoxy(50,13);
			for (int i=0; i<100; i++) {
				if (calif[i]>=30 && calif[i]<=40)
					printf("%c",254); }
			/*Ciclo para imprimir frecuencia del quinto intervalo*/
			gotoxy(50,14);
			for (int i=0; i<100; i++) {
				if (calif[i]>=40 && calif[i]<=50)
					printf("%c",254); }
			/*Ciclo para imprimir frecuencia del sexto intervalo*/
			gotoxy(50,15);
			for (int i=0; i<100; i++) {
				if (calif[i]>=50 && calif[i]<=60)
					printf("%c",254); }
			/*Ciclo para imprimir frecuencia del septimo intervalo*/
			gotoxy(50,16);
			for (int i=0; i<100; i++) {
				if (calif[i]>=60 && calif[i]<=70)
					printf("%c",254); }
			/*Ciclo para imprimir frecuencia del octavo intervalo*/
			gotoxy(50,17);
			for (int i=0; i<100; i++) {
				if (calif[i]>=70 && calif[i]<=80)
					printf("%c",254); }
			/*Ciclo para imprimir frecuencia del noveno intervalo*/
			gotoxy(50,18);
			for (int i=0; i<100; i++) {
				if (calif[i]>=80 && calif[i]<=90)
					printf("%c",254); }
			/*Ciclo para imprimir frecuencia del décimo intervalo*/
			gotoxy(50,19);
			for (int i=0; i<100; i++) {
				if (calif[i]>=90 && calif[i]<=100)
					printf("%c",254); }
			
			SetConsoleTextAttribute(hd,9); 
			x=6, y=23;
			for(int i=x;i<111;i++){ 
			gotoxy(i,y);
			printf("%c",205);} 
			
			x=6, y=4;
			for(int i=x;i<111;i++){ 
			gotoxy(i,y);
			printf("%c",205);} 
			
			x=5,y=5; 
			for(int i=y;i<23;i++){
			gotoxy(x,i);
			printf("%c",186);}
			
			x=111,y=5; 
			for(int i=y;i<23;i++){
			gotoxy(x,i);
			printf("%c",186);}
			
			gotoxy(5,23);
			printf("%c",200);
			
			gotoxy(111,23);
			printf("%c",188);
			
			gotoxy(111,4);
			printf("%c",187);
			
			gotoxy(5,4);
			printf("%c",201);
			
			SetConsoleTextAttribute(hd,1); 
			gotoxy(1,1);
			printf("%c",201); 
			x=2,y=1; 
			for(int i=x;i<117;i++){ 
			gotoxy(i,y);
			printf("%c",205);} 
			
			x=2,y=1; 
			for(int i=x;i<46;i++){ 
			gotoxy(i,y);
			printf("%c",205);}
			 
			gotoxy(117,1);
			printf("%c",187); 
			
			x=1,y=2; 
			for(int i=y;i<26;i++){
			gotoxy(x,i);
			printf("%c",186);} 
			
			x=117,y=2;
			for(int i=y;i<26;i++){
			gotoxy(x,i);
			printf("%c",186);} 
			
			x=2, y=26;
			for(int i=x;i<117;i++){ 
			gotoxy(i,y);
			printf("%c",205);} 
			
			gotoxy(1,26);
			printf("%c",200);
			
			gotoxy(117,26);
			printf("%c",188);
			getch();
			break;
		default: 
			system("cls");
			printf("Seleccionaste una opcion no valida.");
			getch();
			break; }
	} while (opcion!=5);
	system("cls");
	printf("¡Hasta luego!");
}
