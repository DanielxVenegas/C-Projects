#include<stdio.h>
#include<locale.h> //Librer�a que establece el idioma*
#include<stdlib.h> //Librer�a que personaliza la pantalla
main(){
	setlocale(LC_CTYPE, "Spanish"); //Establece el idioma en espa�ol
	system("cls"); //Limpiar pantalla
	system("mode con: lines=60 cols=110"); //Tama�o de pantalla
	system("color 1F"); //Color de fondo y fuente
	printf("\t\t\t\t177603 - Venegas Rivera Daniel Alejandro\n");
	printf("\t\t\t\tProgramaci�n 1, Semestre: II - Primavera 2022\n");
	printf("\t\t\t\t\tPr�ctica 3 - 11/02/2022\n");
	printf("-------------------------------------------------------------------------------------------------------------\n\n");
	printf("\t\t\t\tJerarqu�a de operadores en luenguaje C\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("Nivel\tOperadores\t\t\tAsociaci�n\tDescripci�n.\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("1\t() [] ->\t\t\tIzquierda\tAcceso a un elemento de un vector y par�ntesis.\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("\t+ - ! ~\t\t\t\t\t\tSigno (unario), negaci�n l�gica, negaci�n bit a bit.\n");
	printf("2\t* &\t\t\t\tDerecha\t\tAcceso a un elemento (unarios): puntero y direcci�n.\n");
	printf("\t++ --\t\t\t\t\t\tIncremento y decremento(pre y post)\n.");
	printf("\t(cast) sizeof\t\t\t\t\tConversi�n de tipo (casting) y tama�o de un elemento.\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("3\t* / %c\t\t\t\tIzquierda\tProducto, divisi�n, m�dulo (resto).\n",37);
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("4\t+ -\t\t\t\tIzquierda\tSuma y resta.\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("5\t>> <<\t\t\t\tIzquierda\tDesplazamientos.\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("6\t< <= >= >\t\t\tIzquierda\tComparaciones de superioridad e inferioridad.\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("7\t== !=\t\t\t\tIzquierda\tComparaciones de igualdad.\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("8\t&\t\t\t\tIzquierda\tY (And) bit a bit (binario).\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("9\t^\t\t\t\tIzquierda\tO-exclusivo (Exclusive-Or)(binario).\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("10\t|\t\t\t\tIzquierda\tO (Or) bit a bit (binario).\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("11\t&&\t\t\t\tIzquierda\tY (And) l�gico.\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("12\t||\t\t\t\tIzquierda\tO (Or) l�gico.\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("13\t?:\t\t\t\tDerecha\t\tCondicional.\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("14\t= *= /= %c.= += -=\t\tDerecha\t\tAsignaciones.\n",37);
	printf("\t>>= <<= &= ^= |= -=\n");
	printf("-------------------------------------------------------------------------------------------------------------\n");
	printf("15\t,\t\t\t\tIzquierda\tComa.\n");
	printf("-------------------------------------------------------------------------------------------------------------\n\n");
	printf("Funciones de la librer�a string.h:\n");
	printf("strlen(arg1): Devuelve la longitud del texto representado por el argumento 1.\n");
	printf("strcmp(arg1, arg2): Devuelve 0 si las cadenas representadas por los argumentos son iguales, \no un valor menor que cero si arg1 precede alfab�ticamente a arg2.\n");
	printf("strcat(arg1, arg2): Concatena las cadenas indicadas.\n");
}
