//Lenguaje C
//Librer�as: Utilizar las funciones propias del lenguaje, cada libreria incluye funciones de distinto uso
#include <stdio.h> //Librer�a de entrada y salida de datos

int main()//Funci�n de inicio, siempre debe de ir en el programa
{
/*Variables: Almacena valores distintos
Tipos de datos:
int: %i, %d - Almacena n�meros enteros
char: %c - Almacena caracteres
char[]: %s - Almacena cadenas de caracteres
float: %f - Almacena n�meros con decimal
Condiciones para declarar variables:
- Pueden comenzar con guion bajo
- No deben contener espacios
- No pueden comenzar con n�meros
- No pueden contener palabras reservadas
- Pueden contener may�sculas
- No pueden contener caracteres especiales
- Se les debe asignar nombres significativos
- No se recomienda usar nombres largos*/

//Declaraci�n de variables
char grup = ' '; //Cadena de caracter, el ";" indica que la instrucci�n termina
int alumnos = 0,semestre = 0; //En la declaraci�n de variables es posible inicializar el valor de �stas
float promG = 0; //Se almacena como "0.000000"

//Entrada de datos
printf("\t\tPROGRAMACION 1\n");//Funci�n para imprimir en pantalla texto o valores, "\t" aplica sangr�a al texto por imprimir
printf("Ingresa la cantidad de alumnos: ");
scanf("%d",&alumnos);//Funci�n para leer un dato del teclado y lo almacena en una variable, es importante el uso general del "&" antes de la variable
fflush(stdin);//Funci�n que limpia el buffer de la entrada del teclado
printf("Ingresa el grupo: ");
scanf("%c",&grup);
printf("Ingresa el promedio: ");
scanf("%f",&promG);
printf("Ingresa el semestre: ");
scanf("%i",&semestre);

//Salida de datos
printf("\n\n\t\tSALIDA\n"); //"\n" Es un salto de l�nea
printf("Cantidad: %d\n",alumnos); //Para imprimir una variable, se especifica el tipo de dato precedido de "%" entre comillas dobles, fuera de las comillas se especifica el nombre de la variable
printf("Grupo: %c\nPromedio: %.2f\nSemestre: %d",grup,promG,semestre); //El n�mero de "%.2f" indica el n�mero de decimales que mostrar� la variable float en pantalla
} //Fin de la funci�n "main()"
