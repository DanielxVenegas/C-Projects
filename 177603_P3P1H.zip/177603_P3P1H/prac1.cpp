#include <stdio.h>
#include <string.h> //Librer�a que incluye funciones de cadenas de caracteres
/*Tabla de jerarquia de operadores: El orden en que se realizan las operaciones
(),[],{}
*, /, %
+, -
&&, ||
<,==
*/


main()
{
//declaraci�n de variables. Char se inicializa como ' '
char uno = ' ', cad[10];//nombre de la variable [maximo de caracteres a almacenar]
float sum = 0, v1 = 8, v2 = 8, v3 = 6;
/*
cadenas de caracteres o
Formato: %s, o %[^\n]
gets(cad)
scanf no llevan & porque la cadena en s� misma es la referencia
scanf no lleva [] porque se analiza la cadena completa
*/
//Cuerpo del programa
printf("\nIngresa un nombre: ");
scanf("%s",cad);//pajaro
printf("\nNombre: %s",cad);

printf("\nCociente: %d, Residuo: %d",11/2,11%3); //% Devuelve el residuo de la divisi�n
//sum = (v1+v2+v3)/3; Las variables (o constantes) deben ser tipo float para devolver un valor float
printf("\nOper: %f",(v1+v2+v3)/3);//7.33333 El resultado s�lo se imprime, pero no se asigna a ninguna variable
printf("\nOper: %f",sum);//0.00000 porque a�n no se le asigna otro valor aparte del inicial
printf("\nOper: %f",sum = (v1+v2+v3)/3);//7.33333
printf("\nOper: %f",sum);//7.33333 ya se le asign� un valor en la l�nea anterior
//Seg�n cada programador, puede devolver el resultado de estas maneras

fflush(stdin); //Permite ingresar todos los valores sin omitir ninguno, sin errores
printf("\nIngrese una letra: ");
scanf("%c",&cad[2]); //Lleva & y [] porque es un caracter �nico, no una cadena. 
//Se asigna a la posici�n 2 el valor ingresado
//La primera posici�n es la 0
cad[6] = 'S'; //Se asigna la letra S a la posici�n 6
cad[7] = '6'; //Se asigna el n�mero 6 a la posici�n 7
cad[8] = '$'; //Se asigna el caractter $ a la posici�n 8
printf("\nNombre: %s",cad);
strcpy(cad,"CABALLO");//<<< Esto sustituye a esto >>>> cad = "CABALLO"; funcion para asignarle o copiarle un valor a la cadena
printf("\nFinal: %s",cad); //Muestra el valor de la cadena final, en este caso "CABALLO"
}
