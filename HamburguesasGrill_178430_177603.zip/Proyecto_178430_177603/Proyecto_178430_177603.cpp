/*Librer�as*/
#include <stdio.h>
#include <locale.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
/*Declaraci�n de estructuras globales*/
/*Estructura con informaci�n predeterminada sobre el local*/
int a=200;
int b=600;
struct general {
	int hambTiemp; //N�mero de hamburguesas producidas por unidad de tiempo
	int cocineros; //N�mero de cocineros disponibles
	int prodPed; //N�mero de productos en un pedido
	float tiempoAprox; //Tiempo aproximado en terminar el pedido
};
/*Men�*/
struct catalogo {
	int id; //ID del producto
	char platillo[25]; //Nombre del producto
	float precio;
	struct catalogo *siguiente, *ant; //Listas doblemente enlazadas
};
struct catalogo *primCatalogo=NULL, *ultCatalogo=NULL;
/*Estructura de los trabajadores del negocio*/
struct personal {
	int id; //ID del trabajador
	char nombre[25]; //Nombre del trabajador
	char cargo[12]; //Cocinerx o ventas
	char password[12]; //Cocinerx o ventas
	int pedido;
	struct personal *siguiente, *ant;
};
struct personal *primPersonal=NULL, *ultPersonal=NULL;
/*Reporte de ventas*/
struct reporte {
	int id; //ID del vendedor
	char vendedor[25]; //Nombre del trabajador
	float venta; 
	float tiempo;
	struct reporte *siguiente, *ant;
};
struct reporte *primReporte=NULL, *ultVentas=NULL;
/*Pedidos individuales*/
struct pedidos {
	int idPedido; //ID del pedido general
	char vendedor[25]; //Trabajador que le atendi�
	int idVendedor; //Trabajador que le atendi�
	int idProducto;
	char producto[25];
	int cantProducto; //Cantidad por producto
	float precioUni; //Precio del producto
	float totalProducto; //Precio del producto * cantidad por producto
	float totalPedido; //Sumatoria de los precios
	float tiempoAtencion; //Tiempo estimado de atenci�n
	struct pedidos *siguiente, *ant;
};
struct pedidos *primero=NULL, *ultimo=NULL;

/*Declaracion de funciones*/
void insertarCatalogo(); //Archivos ya implementados
void leerCatalogo(); //Archivos ya implementados
void modificarCatalogo();
void agregarPersonal(); //Archivos implementados
void verPersonal(); //Archivos implementados
void leerPersonal(); //Archivos implementados
void generarReporte();
void insertarReporte();
void insertarPedido();
void programador();
void verCatalogo(); //Archivos implementados

/*Programa principal*/
int main() {
	setlocale(LC_ALL, "Spanish");
	char op, password[7]="admin", intento[7], name[12], pass[7];
	int exit=0, op1, exit1, op2, exit2;
	programador();
	getch();
	system("cls");
	leerPersonal();
	leerCatalogo();
	while(!exit) {
		printf("\nIniciar sesion\n");
		printf("\nA.- Administrador\n");
		printf("B.- Personal\n");
		printf("Z.- Salir\n");
		scanf("%c",&op);
		switch(op) {
			case 'A':
				printf("Contrase�a: ");
				scanf("%s",&intento);
				if(strcmp(intento,password) == 0) exit1=0;
				else {
					printf("Contrase�a incorrecta\n");
					exit1=1;
				}
				while(!exit1) {
					printf("\nCuenta de administrador\n");
					printf("\n\t1.- Insertar platillo\n");
					printf("\t2.- Agregar Personal\n");
					printf("\t3.- Ver platillos\n");
					printf("\t4.- Ver Personal\n");
					printf("\t0.- Salir\n");
					scanf("\t%d",&op1);
					
					switch(op1) {
						case 1: 
							insertarCatalogo();
							break;
						case 2:
							agregarPersonal();
							break;
						break;
						case 3:
							verCatalogo();
							break;
						case 4:
							verPersonal();
							break;
						case 0: 
							exit1=1;
							break;
					}
				}
				break;
			case 'B':
				struct personal *aux;
				printf("Nombre: ");
				scanf("%s",&name);
				printf("Contrase�a: ");
				scanf("%s",&pass);
				aux=primPersonal;
				while (aux!=NULL) {
			        if(strcmp(name,aux->nombre) == 0 && strcmp(pass,aux->password) == 0) {
			        	exit2=0;
			        	break;
					} 
			        else exit2=1;
			        aux=aux->siguiente;
			    }
				if(exit2 == 1) printf("Contrasena incorrecta\n");
				while (!exit2){
					printf("\tCuenta de personal de ventas\n");
					printf("\n\t1.- Insertar Pedido\n");
					printf("\t2.- Personal\n");
					printf("\t0.- Salir\n");
					scanf("\t%d",&op2);
					switch(op2) {
						case 1:
							verCatalogo();
							insertarPedido();
							break;
						case 2:  
							break;
						case 0: 
							exit2=1;
							break;
					}
				}
				break;
			case 'Z': 
				exit=1;
				break;
			}
	}  
}

/*Desarrollo de funciones*/
void programador(){
	printf("Venegas Rivera Daniel Alejandro\nMatr�cula: 177603\n");
	printf("Estrada Medina Monserrat\nMatr�cula: 178430\n");
	printf("Ingenieria en Tecnolog�as de la Informaci�n\nProgramaci�n II\n\n");
	printf("Proyecto: Hamburguesas Grill\n");
}

void insertarCatalogo() {
	struct catalogo *nuevo;
	FILE *archivo;
	int id;
	a=a+10;

	/* reservamos memoria para el nuevo elemento */
    nuevo = (struct catalogo *) malloc (sizeof(struct catalogo));
    if (nuevo==NULL) {
    	printf( "No hay memoria disponible!\n");
    	return; 
	}
    nuevo->id=a;
    
    
    printf("Nombre del platillo:");
    scanf("%s",nuevo->platillo);
    printf("\nPrecio:");
    scanf("%f",&nuevo->precio);
    nuevo->siguiente = NULL; 
    
    if (primCatalogo==NULL) {
        primCatalogo = nuevo;
        ultCatalogo = nuevo;
        nuevo->ant=NULL;
        nuevo->siguiente=NULL;
    } 
    else {
        /* el que hasta ahora era el �ltimo tiene que apuntar al nuevo */
        ultCatalogo->siguiente = nuevo;
        nuevo->ant=ultCatalogo ;
        nuevo->siguiente=NULL;
    	/* hacemos que el nuevo sea ahora el �ltimo */
        ultCatalogo = nuevo;
    }
	archivo = fopen("catalogo.txt","a+");
	fprintf(archivo, "%d\t%s\t%.2f\n", nuevo->id, nuevo->platillo, nuevo->precio);
	fclose(archivo);
}

/*Funci�n para cargar la informaci�n preexistente del catalogo a la lista*/
void leerCatalogo(void) {
	struct catalogo *nuevo;
	FILE *archivo; //Apuntador a archivo
	/*Lectura de informaci�n preexistente*/
	archivo = fopen("catalogo.txt","r");
	if(archivo == NULL) {
		printf("No se encontr� el archivo");
		return;
	}
    while(!feof(archivo)) {
    	/*Reserva de memoria para el nuevo elemento */
	    nuevo = (struct catalogo *) malloc(sizeof(struct catalogo));
	    if(nuevo == NULL) {
	    	printf("No hay memoria disponible!\n");
	    	return; 
		}
    	fscanf(archivo, "%d\t", &nuevo->id);
    	fscanf(archivo, "%s\t", &nuevo->platillo);
    	fscanf(archivo, "%f\n", &nuevo->precio);
    	/*Insercion en lista vac�a*/
    	if (primCatalogo == NULL) {
	    	primCatalogo = nuevo;
	        ultCatalogo = nuevo;
	        nuevo->ant=NULL;
	        nuevo->siguiente=NULL;
	    } else { /*Inserci�n al final de la lista*/
	        ultCatalogo->siguiente = nuevo;
	        nuevo->ant=ultCatalogo;
	        nuevo->siguiente=NULL;
	        ultCatalogo=nuevo;
		}
		
	}
    fclose(archivo);
}

void agregarPersonal() {
	FILE *archivo;
	struct personal *nuevo;
	char cocino[12]={"Cocinero"};
	char cocina[12]={"Cocinera"};
    /*Reserva de memoria para el nuevo elemento */
    nuevo = (struct personal *) malloc(sizeof(struct personal));
    if(nuevo == NULL) {
    	printf( "No hay memoria disponible!\n");
    	return; 
	}
    nuevo->id=b+10;
    printf("Nombre del trabajador: ");
    scanf("%s",nuevo->nombre);
    printf("\nCargo: ");
    scanf("%s",nuevo->cargo);
    printf("\nContrasena: ");
    scanf("%s",nuevo->password);
    if(strcmp(cocina,nuevo->cargo)==0 || strcmp(cocina,nuevo->cargo)==0) nuevo->pedido=0;
    else nuevo->pedido=1;
    nuevo->siguiente = NULL;
    /*Inserci�n en lista vac�a*/
    if (primPersonal==NULL) {
        printf("\n");
    	primPersonal = nuevo;
        ultPersonal = nuevo;
        nuevo->ant=NULL;
        nuevo->siguiente=NULL;
    }
    else {
        /*Inserci�n al final de la lista*/
        ultPersonal->siguiente = nuevo;
        nuevo->ant=ultPersonal;
        nuevo->siguiente=NULL;
        /* hacemos que el nuevo sea ahora el �ltimo */
        ultPersonal = nuevo;
	}
	archivo = fopen("personal.txt","a+");
	fprintf(archivo, "%d\t%s\t%s\t%s\n", nuevo->id, nuevo->nombre, nuevo->cargo, nuevo->password);
	fclose(archivo);
}

void insertarPedido() {
	FILE *archivo;
	struct pedidos *nuevo; 
	struct catalogo *aux;
	struct personal *temp; //Para asignar un vendedor al pedido
	int i,a=0,id;
	i=1;
	int aux1=0;
	aux = primCatalogo;
	b=b+10;
	
	/* reservamos memoria para el nuevo elemento */
    nuevo = (struct pedidos *) malloc (sizeof(struct pedidos));
    if (nuevo==NULL) {
    	printf( "No hay memoria disponible!\n");
    	return; 
	}
	/*Se asigna automaticamente*/
	temp=primPersonal;
	while (temp != NULL) {
		if(temp->pedido == 0) {
			strcpy(nuevo->vendedor, temp->nombre);
			nuevo->idVendedor=temp->id;
			printf("%d\t%s\n", nuevo->idVendedor, nuevo->vendedor);
			break;
		} 
		temp=temp->siguiente;
	}
	while(aux1==0) {
		
	    nuevo->idPedido=b;
	    
	    printf("Ingrese ID del platillo:");
	    scanf("%d",&id);
	    
	    while(aux!=NULL){
			if(id==aux->id){
				printf("\nId producto: %d",aux->id);
			    printf("\tNombre del producto: %s",aux->platillo);
			    printf("\tPrecio unitario: %.2f\n",aux->precio);
			    printf("\nCantidad: ");
	    		scanf("%d",&nuevo->cantProducto);
	    		nuevo->totalProducto=aux->precio*nuevo->cantProducto;
	    		nuevo->totalPedido+=nuevo->totalProducto;
	    		nuevo->tiempoAtencion=15+rand()%(45-15+1);
	    		nuevo->siguiente = NULL; 
	    		if (primero==NULL){
			     	primero = nuevo;
			     	ultimo = nuevo;
			     	nuevo->ant=NULL;
			     	nuevo->siguiente=NULL;
				} 
			
			    else{
				   ultimo->siguiente = nuevo;
				   nuevo->ant=ultimo;
				   nuevo->siguiente=NULL;
				   ultimo = nuevo;   
			    }
				a++;
				break;		
			}else{
				aux = aux->siguiente;
				i++;
			}
		}
		if(a==0){
			printf("\nID no valido\n\n");
		}
    printf("Si se requiere agregar otro producto a la orden ingresa 0, de no ser asi, ingresar 1\n");
    scanf("%d",&aux1);
	}
    
    printf("\n\nRESUMEN DE LA ORDEN");
	printf("\nId orden: %d",nuevo->idPedido);
    printf("\nId producto: %d",aux->id);
    printf("\tNombre del producto: %s",aux->platillo);
    printf("\tPrecio unitario: %.2f\n",aux->precio);
    printf("\nCantidad: %d",nuevo->cantProducto);
    printf("\nTotal: %.2f\n\n",nuevo->totalPedido);
    
    archivo = fopen("pedidos.txt","a+");
	fprintf(archivo, "%d\t%s\t%d\t%s\t", nuevo->idPedido, nuevo->vendedor, nuevo->idProducto, nuevo->producto);
	fclose(archivo);
}

void verCatalogo(){
	struct catalogo *auxiliar; /* lo usamos para recorrer la lista */
      int i;
      i=0;
      auxiliar = primCatalogo;
      printf("\n\n\nMostrando men� completo:\n");
      printf("--------------------------------\n");
      printf("ID\tPLATILLO\tPRECIO\n");
      while (auxiliar!=NULL) {
            printf("%d\t%s\t\t%.2f\n",auxiliar->id,auxiliar->platillo,auxiliar->precio);
            auxiliar = auxiliar->siguiente;
            i++;
      }
      if (i==0) printf( "\n�La lista est� vac�a!\n" );
}
/*Funci�n para recorrer la lista de personal*/
void verPersonal(){
	struct personal *aux; //auxiliar para recorrer la lista
      aux=primPersonal;
      printf("ID\tNombre\t\tCargo\t\tPedido\n");
      while (aux!=NULL) {
        printf("%d\t%s\t\t%s\t",aux->id,aux->nombre,aux->cargo);
        if(aux->pedido == 0) printf("Libre\n");
        else printf("%d\n",aux->pedido);
        aux=aux->siguiente;
      }
}
/*Funci�n para cargar la informaci�n preexistente del personal a la lista*/
void leerPersonal(void) {
	struct personal *nuevo;
	FILE *archivo; //Apuntador a archivo
	char cocino[12]={"Cocinero"};
	char cocina[12]={"Cocinera"};
	/*Lectura de informaci�n preexistente*/
	archivo = fopen("personal.txt","r");
	if(archivo == NULL) {
		printf("No se encontr� el archivo");
		return;
	}
    while(!feof(archivo)) {
    	/*Reserva de memoria para el nuevo elemento */
	    nuevo = (struct personal *) malloc(sizeof(struct personal));
	    if(nuevo == NULL) {
	    	printf( "No hay memoria disponible!\n");
	    	return; 
		}
    	fscanf(archivo, "%d\t", &nuevo->id);
    	fscanf(archivo, "%s\t", &nuevo->nombre);
    	fscanf(archivo, "%s\n", &nuevo->cargo);
    	fscanf(archivo, "%s\n", &nuevo->password);
    	if(strcmp(cocina,nuevo->cargo)==0 || strcmp(cocino,nuevo->cargo)==0) nuevo->pedido=0;
    	else nuevo->pedido=1;
    	/*Insercion en lista vac�a*/
    	if (primPersonal == NULL) {
	    	primPersonal = nuevo;
	        ultPersonal = nuevo;
	        nuevo->ant=NULL;
	        nuevo->siguiente=NULL;
	    } else { /*Inserci�n al final de la lista*/
	        ultPersonal->siguiente = nuevo;
	        nuevo->ant=ultPersonal;
	        nuevo->siguiente=NULL;
	        ultPersonal=nuevo;
		}
	}
    fclose(archivo);
}
/*Reporte total de ventas
Asignar pedidos por tiempo al cocinero*/
