/*Librerias*/
#include <stdio.h> //Posee funciones para entrada y salida de datos
#include <conio.h> //Incluye funciones para manipular la consola en modo texto
#include <stdlib.h> //Conversion numerica, generacion de aleatorios y reserva de memoria
#include <string.h> //Libreria para manipular cadenas de caracteres
#include <windows.h> //Entorno grafico de la consola

/*Declaracion de estructuras globales*/
/*Estructura con informacion predeterminada sobre el local*/
struct general {
	int hambTiemp; //Numero de hamburguesas producidas por unidad de tiempo
	int cocineros; //Numero de cocineros disponibles
	int prodPed; //Numero de productos en un pedido
	float tiempoAprox; //Tiempo aproximado en terminar el pedido
};
/*Estrcutura con la informacion de cada platillo en el menu*/
struct catalogo {
	int id; //ID del producto
	char platillo[25]; //Nombre del producto
	float precio;
	struct catalogo *siguiente, *ant; //Listas doblemente enlazadas
};
struct catalogo *primCatalogo=NULL, *ultCatalogo=NULL;
/*Estructura con informacion de los trabajadores del negocio*/
struct personal {
	int id; //ID del trabajador
	char nombre[25]; //Nombre del trabajador
	char cargo[12]; //Cocinerx o ventas
	char password[12]; //Cocinerx o ventas
	int pedido;
	struct personal *siguiente, *ant;
};
struct personal *primPersonal=NULL, *ultPersonal=NULL;
/*Reporte de ventas*/
struct reporte {
	int id; //ID del vendedor
	char vendedor[25]; //Nombre del trabajador
	float venta; 
	float tiempo;
	struct reporte *siguiente, *ant;
};
struct reporte *primReporte=NULL, *ultVentas=NULL;
/*Pedidos individuales*/
struct pedidos {
	int idPedido; //ID del pedido general
	char vendedor[25]; //Persona que atendio
	char cocinero[25]; //Persona que preraro la orden
	int idVendedor;
	int idCocinero;
	int idProducto;
	char producto[25];
	int cantProducto; //Cantidad por producto
	float precioUni; //Precio del producto
	float totalProducto; //Precio del producto * cantidad por producto
	float totalPedido; //Sumatoria de los precios
	int tiempoAtencion; //Tiempo estimado de atencion
	struct pedidos *siguiente, *ant;
	char fecha[9];
};
struct pedidos *primero=NULL, *ultimo=NULL;
/*Generacion de reporte de ventas por dia*/
struct repDia{
	char fecha[9];
	float total;
	struct repDia *siguiente, *ant; //Listas doblemente enlazadas
};
struct repDia *primrepDia=NULL, *ultrepDia=NULL;

/*Declaracion de variables globales para manipular ID*/
int a=100;
int b=500;
int c=100;

/*Declaracion de funciones*/
void portada();
void insertarCatalogo(); //Archivos ya implementados
void leerCatalogo(); //Archivos ya implementados
void modificarCatalogo();
void agregarPersonal(); //Archivos implementados
void verPersonal(); //Archivos implementados
void leerPersonal(); //Archivos implementados
void generarReporte();
void insertarReporte();
void insertarPedido(struct personal *user);
void programador();
void verCatalogo(); //Archivos implementados
void reporteTotDia();
void ventas();
void VereporteTotDia();
void reporteTotal();
void reporteVentas();
void asignarCocinerx(struct pedidos *nuevo, struct personal *aux2); //Funcion recursiva para asignar cocinerx

/*Funcion gotoxy para manipular la consola*/
void gotoxy(int x, int y) {
	HANDLE hcon;
	hcon = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD dwPos;
	dwPos.X = x;
	dwPos.Y= y;
	SetConsoleCursorPosition(hcon,dwPos); }
HANDLE hd = GetStdHandle(STD_OUTPUT_HANDLE); //Establecer consola en modo grafico

/*Programa principal*/
int main() {
	system("color F0"); //Color de fondo blanco, texto negro
	system("mode con cols=75 lines=35"); //Tamano de la pantalla
	SetConsoleTextAttribute(hd, 240); //Fondo blanco, texto negro
	char op, password[7]="admin", intento[7], name[12], pass[7], cuenta[12]="Ventas";
	int exit=0, op1, exit1, op2, exit2;
	portada();
	getch();
	system("cls");
	leerPersonal();
	leerCatalogo();
	while(!exit) {
		printf("\nIniciar sesion\n");
		printf("\nA.- Administrador\n");
		printf("B.- Personal\n");
		printf("Z.- Salir\n");
		scanf("%c",&op);
		switch(op) {
			case 'A':
				printf("Contrasena: ");
				scanf("%s",&intento);
				if(strcmp(intento,password) == 0) exit1=0;
				else {
					printf("Contrasena incorrecta\n");
					exit1=1;
				}
				while(!exit1) {
					system("CLS");
					printf("\nCuenta de administrador\n");
					printf("\n\t1.- Insertar platillo\n");
					printf("\t2.- Agregar Personal\n");
					printf("\t3.- Ver platillos\n");
					printf("\t4.- Ver Personal\n");
					printf("\t5.- Generar reporte total por dia\n");
					printf("\t6.- Ver reporte total por dia\n");
					printf("\t7.- Ver reporte total\n");
					printf("\t8.- Ver reporte de pedidos por vendedor\n");
					printf("\t9.- Ver reporte de todas las ventas\n");
					printf("\t0.- Salir\n");
					scanf("\t%d",&op1);
					switch(op1) {
						case 1: 
							system("CLS");
							insertarCatalogo();
							getch();
							break;
						case 2:
							system("CLS");
							agregarPersonal();
							getch();
							break;
						break;
						case 3:
							system("CLS");
							verCatalogo();
							getch();
							break;
						case 4:
							system("CLS");
							verPersonal();
							getch();
							break;
						case 5: 
							system("CLS");
							reporteTotDia();
							break;
						case 6:
							system("CLS");
							VereporteTotDia();
							getch();
							break;
						case 7:
							system("CLS");
							reporteTotal();
							getch();
							break;
						case 8:
							system("CLS");
							reporteVentas();
							getch();
							break;
						case 9:
							system("CLS");
							ventas();
							getch();
							break;
						case 0: 
							exit1=1;
							system("CLS");
							getch();
							break;
					}
					system("CLS");
				}
				break;
			case 'B':
				struct personal *user;
				printf("Nombre: ");
				scanf("%s",&name);
				printf("Contrasena: ");
				scanf("%s",&pass);
				user=primPersonal;
				while (user!=NULL) {
					/*Validacion para que el nombre y contrasena del vendedor coincidan*/
			        if(strcmp(name,user->nombre) == 0 && strcmp(pass,user->password) == 0 && strcmp(cuenta,user->cargo) == 0) {
			        	exit2=0;
			        	break;
					} 
			        else exit2=1;
			        user=user->siguiente;
			    }
			    if(exit2 == 1) printf("Contrasena incorrecta\n");
				while (!exit2) {
					system("CLS");
					printf("\tCuenta de personal de ventas\n");
					printf("\n\t1.- Insertar Pedido\n");
					printf("\t0.- Salir\n");
					scanf("\t%d",&op2);
					switch(op2) {
						case 1:
							system("CLS");
							verCatalogo();
							insertarPedido(user);
							getch();
							break;
						case 0: 
							exit2=1;
							break;
					}
				}
				system("CLS");
				break;
			case 'Z': 
				exit=1;
				break;	
		}
	}  
}

/*Desarrollo de funciones*/
/*Funcion para imprimir portada*/
void portada() {
	int x=3, y=1;
	/*Imprimir division superior*/
	gotoxy(x,y);
	printf("%c", 218);
	for(x=4; x<71; x++) {
		gotoxy(x,y);
		printf("%c", 196);
	}
	/*Imprimir division derecha*/
	printf("%c", 191);
	for(y=2; y<33; y++) {
		gotoxy(x,y);
		printf("%c", 179);
	}
	/*Imprimir division inferior*/
	gotoxy(x,y);
	printf("%c", 217);
	for(x=70; x>3; x--) {
		gotoxy(x,y);
		printf("%c", 196);
	}
	/*Imprimir division izquierda*/
	gotoxy(x,y);
	printf("%c", 192);
	for(y=32; y>1; y--) {
		gotoxy(x,y);
		printf("%c", 179);
	}
	/*Imprimir texto con formato*/
	SetConsoleTextAttribute(hd, 246); //Fondo blanco, texto cafe
	x=32;
	y=10;
	gotoxy(x,y);
	printf("Hamburguesas");
	x=35;
	y++;
	gotoxy(x,y);
	SetConsoleTextAttribute(hd, 244);  //Fondo blanco, texto rojo
	printf("Grill");
	/*Impresion de dibujo*/
	x=25;
	y+=3;
	gotoxy(x,y);
	SetConsoleTextAttribute(hd, 102); //Cafe
	for(int i=0; i<26; i++) printf(" ");
	x--;
	y++;
	gotoxy(x,y);
	for(int i=0; i<28; i++) printf(" ");
	x--;
	y++;
	gotoxy(x,y);
	for(int i=0; i<30; i++) printf(" ");
	y++;
	gotoxy(x,y);
	SetConsoleTextAttribute(hd, 68); //Rojo
	for(int i=0; i<30; i++) printf(" ");
	y++;
	gotoxy(x,y);
	SetConsoleTextAttribute(hd, 238); //Amarillo
	for(int i=0; i<30; i++) printf(" ");
	y++;
	gotoxy(x,y);
	SetConsoleTextAttribute(hd, 170); //Verde
	for(int i=0; i<30; i++) printf(" ");
	y++;
	gotoxy(x,y);
	SetConsoleTextAttribute(hd, 102); //Cafe
	for(int i=0; i<30; i++) printf(" ");
	x++;
	y++;
	gotoxy(x,y);
	for(int i=0; i<28; i++) printf(" ");
	/*Impresion de texto*/
	SetConsoleTextAttribute(hd, 240); //Blanco con texto negro
	x=16;
	y+=3;
	gotoxy(x,y);
	printf("Universidad Politecnica de San Luis Potosi");
	x=16;
	y++;
	gotoxy(x,y);
	printf("Ingenieria en Tecnologias de la Informacion");
	x=22;
	y++;
	gotoxy(x,y);
	printf("Laboratorio de Programacion II");
	x=21;
	y+=2;
	gotoxy(x,y);
	printf("Estrada Medina Monserrat - 178430");
	x=17;
	y++;
	gotoxy(x,y);
	printf("Venegas Rivera Daniel Alejandro - 177603");

}
/*Funcion para registrar pedidos en el menu*/
void insertarCatalogo() {
	struct catalogo *nuevo;
	FILE *archivo;
	int id;
	a=a+10;
	/*Reserva de memoria*/
    nuevo = (struct catalogo *) malloc(sizeof(struct catalogo));
    if (nuevo==NULL) {
    	printf( "No hay memoria disponible!\n");
    	return; 
	}
	/*Informacion del platillo*/
    nuevo->id=a;
    printf("Nombre del platillo:");
    scanf("%s",nuevo->platillo);
    printf("\nPrecio:");
    scanf("%f",&nuevo->precio);
    nuevo->siguiente = NULL; 
    /*Insercion en la lista*/
    if (primCatalogo==NULL) {
        primCatalogo = nuevo;
        ultCatalogo = nuevo;
        nuevo->ant=NULL;
        nuevo->siguiente=NULL;
    } 
    else {
        /* el que hasta ahora era el ultimo tiene que apuntar al nuevo */
        ultCatalogo->siguiente = nuevo;
        nuevo->ant=ultCatalogo ;
        nuevo->siguiente=NULL;
    	/* hacemos que el nuevo sea ahora el ultimo */
        ultCatalogo = nuevo;
    }
	archivo = fopen("catalogo.txt","a+");
	fprintf(archivo, "%d\t%s\t%.2f\n", nuevo->id, nuevo->platillo, nuevo->precio);
	fclose(archivo);
}

/*Funcion para cargar la informacion preexistente del catalogo a la lista*/
void leerCatalogo(void) {
	struct catalogo *nuevo;
	FILE *archivo; //Apuntador a archivo
	/*Lectura de informacion preexistente*/
	archivo = fopen("catalogo.txt","r");
	if(archivo == NULL) {
		printf("No se encontro el archivo");
		return;
	}
    while(!feof(archivo)) {
    	/*Reserva de memoria para el nuevo elemento */
	    nuevo = (struct catalogo *) malloc(sizeof(struct catalogo));
	    if(nuevo == NULL) {
	    	printf("No hay memoria disponible!\n");
	    	return; 
		}
    	fscanf(archivo, "%d\t", &nuevo->id);
    	fscanf(archivo, "%s\t", &nuevo->platillo);
    	fscanf(archivo, "%f\n", &nuevo->precio);
    	/*Insercion en lista vacia*/
    	if (primCatalogo == NULL) {
	    	primCatalogo = nuevo;
	        ultCatalogo = nuevo;
	        nuevo->ant=NULL;
	        nuevo->siguiente=NULL;
	    } else { /*Insercion al final de la lista*/
	        ultCatalogo->siguiente = nuevo;
	        nuevo->ant=ultCatalogo;
	        nuevo->siguiente=NULL;
	        ultCatalogo=nuevo;
		}
	}
    fclose(archivo);
}

void agregarPersonal() {
	FILE *archivo;
	struct personal *nuevo;
	char cocino[12]={"Cocinero"};
	char cocina[12]={"Cocinera"};
	c=c+15;
    /*Reserva de memoria para el nuevo elemento */
    nuevo = (struct personal *) malloc(sizeof(struct personal));
    if(nuevo == NULL) {
    	printf( "No hay memoria disponible!\n");
    	return; 
	}
    nuevo->id=c;
    printf("Nombre del trabajador: ");
    scanf("%s",nuevo->nombre);
    printf("\nCargo: ");
    scanf("%s",nuevo->cargo);
    printf("\nContrasena: ");
    scanf("%s",nuevo->password);
    if(strcmp(cocina,nuevo->cargo)==0 || strcmp(cocino,nuevo->cargo)==0) nuevo->pedido=0;
    else nuevo->pedido=1;
    nuevo->siguiente = NULL;
    /*Insercion en lista vacia*/
    if (primPersonal==NULL) {
        printf("\n");
    	primPersonal = nuevo;
        ultPersonal = nuevo;
        nuevo->ant=NULL;
        nuevo->siguiente=NULL;
    }
    else {
        /*Insercion al final de la lista*/
        ultPersonal->siguiente = nuevo;
        nuevo->ant=ultPersonal;
        nuevo->siguiente=NULL;
        /* hacemos que el nuevo sea ahora el ultimo */
        ultPersonal = nuevo;
	}
	archivo = fopen("personal.txt","a+");
	fprintf(archivo, "%d\t%s\t%s\t%s\n", nuevo->id, nuevo->nombre, nuevo->cargo, nuevo->password);
	fclose(archivo);
}

void insertarPedido(struct personal *user) {
	FILE *archivo;
	struct pedidos *nuevo; 
	struct catalogo *aux;
	struct personal *aux2; //Para asignar un cocinero al pedido
	int i=1, a=0, id, aux1=1;
	aux = primCatalogo;
	b=b+10;
	/*Reserva de memoria para el nuevo pedido*/
	nuevo = (struct pedidos *) malloc(sizeof(struct pedidos));
    if (nuevo==NULL) {
    	printf( "No hay memoria disponible!\n");
    	return; 
	}
	/*Se asigna automaticamente al vendedor que ingreso a la cuenta*/
	nuevo->idVendedor=user->id;
	strcpy(nuevo->vendedor, user->nombre);
	printf("\nFecha (dd/mm/aa): ");
	scanf("%s",nuevo->fecha);
	/*Ordenes a registrar*/
	while(aux1==1) {
		aux = primCatalogo;
	    id=0;
	    printf("Ingrese ID del platillo: ");
	    scanf("%d",&id);
		/*Asignar platillo*/
	    while(aux != NULL) {
			if(id == aux->id) {
			    /*Registro de la orden*/
			    printf("\nNombre del producto: %s",aux->platillo);
			    printf("\tPrecio unitario: %.2f\n",aux->precio);
			    printf("\nCantidad: ");
	    		scanf("%d",&nuevo->cantProducto);
				/*Generacion del pedido*/
				nuevo->idPedido=b;
	    		nuevo->totalProducto=aux->precio*nuevo->cantProducto;
	    		nuevo->totalPedido+=nuevo->totalProducto;
	    		nuevo->tiempoAtencion=15+rand()%(45-15+1);
	    		/*Insercion del pedido a la lista*/
	    		nuevo->siguiente = NULL;
	    		if (primero==NULL) {
			     	primero = nuevo;
			     	ultimo = nuevo;
			     	nuevo->ant=NULL;
			     	nuevo->siguiente=NULL;
				} else {
				   ultimo->siguiente = nuevo;
				   nuevo->ant=ultimo;
				   nuevo->siguiente=NULL;
				   ultimo = nuevo;   
			    }
				a++;
				break;	
			} else {
				aux = aux->siguiente;
				i++;
			}
		}
		if(a==0) {
			printf("\nID no valido\n\n");
			getch();
			nuevo=NULL;
			free(nuevo);
			break;
		}
	    printf("Si quiere hacer otra orden ingresa 1, de no ser asi, ingresar 0\n");
	    scanf("%d",&aux1);
	}
    if(a != 0) {
    	system("CLS");
    	printf("\n\nRESUMEN DE LA ORDEN");
		printf("\nVendedor: %s", nuevo->vendedor);
    	printf("\tFecha: %s", nuevo->fecha);
		printf("\nId orden: %d", nuevo->idPedido);
	    printf("\nTotal: %.2f\n\n", nuevo->totalPedido);
	    getch();
	}else return;
	asignarCocinerx(nuevo, aux2);
    archivo = fopen("pedidos.txt","a+");
	fprintf(archivo, "%d\t%s\t%d\t%s\t", nuevo->idPedido, nuevo->vendedor, nuevo->idProducto, nuevo->producto);
	fclose(archivo);
}
void asignarCocinerx(struct pedidos *nuevo, struct personal *aux) {
	char cocina[12]="Cocinera", cocino[12]="Cocinero";
	bool bandera=false;
	aux=primPersonal;
	while(aux != NULL) {
		if(strcmp(aux->cargo,cocina)==0 || strcmp(aux->cargo,cocino)==0) {
			if (aux->pedido == 0) {
				nuevo->idCocinero=aux->id;
				strcpy(nuevo->cocinero, aux->nombre);
				aux->pedido=nuevo->idPedido;
				bandera=true;
				return;
			}
		} else aux=aux->siguiente;
	}
	if(bandera == false) {
		primPersonal->pedido=0;
		asignarCocinerx(nuevo, aux);
	}
}
/*Funcion para consultar los platillos*/
void verCatalogo() {
	struct catalogo *auxiliar; /* lo usamos para recorrer la lista */
      int i;
      i=0;
      auxiliar = primCatalogo;
      printf("\nMostrando menu completo:\n");
      printf("--------------------------------\n");
      printf("ID\tPLATILLO\tPRECIO\n");
      while (auxiliar!=NULL) {
            printf("%d\t%s\t\t%.2f\n",auxiliar->id,auxiliar->platillo,auxiliar->precio);
            auxiliar = auxiliar->siguiente;
            i++;
      }
      if (i==0) printf( "\n�La lista esta vacia!\n" );
}
/*Funcion para recorrer la lista de personal*/
void verPersonal() {
	struct personal *aux; //auxiliar para recorrer la lista
    aux=primPersonal;
    printf("ID\tNombre\t\tCargo\t\tPedido\n");
    while (aux!=NULL) {
    	printf("%d\t%s\t\t%s\t",aux->id,aux->nombre,aux->cargo);
        if(aux->pedido == 0) printf("Libre\n");
        else printf("%d\n",aux->pedido);
        aux=aux->siguiente;
    }
}
/*Funcion para cargar la informacion preexistente del personal a la lista*/
void leerPersonal(void) {
	struct personal *nuevo;
	FILE *archivo; //Apuntador a archivo
	char cocino[12]={"Cocinero"};
	char cocina[12]={"Cocinera"};
	/*Lectura de informacion preexistente*/
	archivo = fopen("personal.txt","r");
	if(archivo == NULL) {
		printf("No se encontro el archivo");
		return;
	}
    while(!feof(archivo)) {
    	/*Reserva de memoria para el nuevo elemento */
	    nuevo = (struct personal *) malloc(sizeof(struct personal));
	    if(nuevo == NULL) {
	    	printf( "No hay memoria disponible!\n");
	    	return; 
		}
    	fscanf(archivo, "%d\t", &nuevo->id);
    	fscanf(archivo, "%s\t", &nuevo->nombre);
    	fscanf(archivo, "%s\t", &nuevo->cargo);
    	fscanf(archivo, "%s\n", &nuevo->password);
    	if(strcmp(cocina,nuevo->cargo)==0 || strcmp(cocino,nuevo->cargo)==0) nuevo->pedido=0;
    	else nuevo->pedido=1;
    	/*Insercion en lista vacia*/
    	if (primPersonal == NULL) {
	    	primPersonal = nuevo;
	        ultPersonal = nuevo;
	        nuevo->ant=NULL;
	        nuevo->siguiente=NULL;
	    } else { /*Insercion al final de la lista*/
	        ultPersonal->siguiente = nuevo;
	        nuevo->ant=ultPersonal;
	        nuevo->siguiente=NULL;
	        ultPersonal=nuevo;
		}
	}
    fclose(archivo);
}

void reporteTotDia() {
	struct pedidos *aux = primero;
	int a = 0;
    while (aux != NULL){
	    struct pedidos *aux2 = aux->siguiente;
	    while (aux2 != NULL){
	    	struct repDia *nuevo = (struct repDia *)malloc(sizeof(struct repDia));
	        if (nuevo == NULL) {
	            printf("No hay memoria disponible!\n");
	            return;
	        }
	        	if (strcmp(aux->fecha, aux2->fecha) == 0) {
		            strcpy(nuevo->fecha, aux->fecha);
		            nuevo->total = aux2->totalPedido + aux->totalPedido;
		            nuevo->siguiente = NULL;
		            
		            if (primrepDia == NULL){
		                primrepDia = nuevo;
		                ultrepDia = nuevo;
		                nuevo->ant = NULL;
		                nuevo->siguiente = NULL;
		            } 
					else{
		                ultrepDia->siguiente = nuevo;
		                nuevo->ant = ultrepDia;
		                nuevo->siguiente = NULL;
		                ultrepDia = nuevo;
		            }
		            a++;
	       		}
	        aux2 = aux2->siguiente;
		}
		aux = aux->siguiente;
		
	    if (aux != NULL) {
	        aux2 = aux->siguiente;
	    }	
	}
}

void VereporteTotDia(){
	struct repDia *auxiliar; /* lo usamos para recorrer la lista */
      int i;
      i=0;
      auxiliar = primrepDia;
      printf("FECHA\tTOTAL DE VENTAS\n");
      printf("--------------------------------\n");
      while (auxiliar!=NULL) {
            printf("%s\t%.2f\n",auxiliar->fecha,auxiliar->total);
            auxiliar = auxiliar->siguiente;
            i++;
      }
      if (i==0) printf( "\n�La lista esta vacia!\n" );
}

void reporteTotal(){
	struct reporte *aux;
    aux = primReporte;
    printf("ID Venta\tVendedor\tTotal\tTiempo\n");
    printf("--------------------------------\n");
    if(primReporte == NULL) {
    	printf("No hay reporte de ventas!\n");
    	return;
	}
    while (aux != NULL) {
        printf("%d\t%s\t%.2f\t%d\n", aux->id, aux->vendedor, aux->venta, aux->tiempo);
        aux=aux->siguiente;
    }
}

void reporteVentas() {
	struct personal *aux;
	struct pedidos *temp;
	char nombre[25];
	char cargo[12]="Ventas";
	aux = primPersonal;
	temp = primero;
	printf("Vendedor a buscar: ");
	scanf("%s", nombre);
	if(primPersonal == NULL) {
    	printf("No hay ventas!\n");
    	return;
	}
	if(primero == NULL) {
    	printf("No hay pedidos!\n");
    	return;
	}
	while (aux != NULL) {
		if(strcmp(nombre, aux->nombre)==0 && strcmp(cargo, aux->cargo)==0) {
			printf("\nReporte de ventas: %s\n", aux->nombre);
			while(temp != NULL) {
				if(strcmp(temp->vendedor, aux->nombre) == 0) {
					printf("ID Vendedor: %d\n", temp->idVendedor);
					printf("Vendedor: %s\n", temp->vendedor);
					printf("ID Pedido: %d\n", temp->idPedido);
					printf("Producto: %s\n", temp->producto);
					printf("Precio unitario: %.2f\n", temp->precioUni);
					printf("Cantidad: %d\n", temp->cantProducto);
					printf("Total: %.2f\n", temp->totalPedido);
				} else temp=temp->siguiente;
			}
		} else aux=aux->siguiente;
    }
}

void ventas() {
	struct pedidos *aux; /* lo usamos para recorrer la lista */
      int i;
      i=0;
      aux = primero;
      printf("RESUMEN\n");
      printf("--------------------------------\n");
      while (aux!=NULL) {
        printf("\nRESUMEN DE LA ORDEN\n");
		printf("ID orden: %d\n",aux->idPedido);
		printf("ID Vendedor: %d\t",aux->idVendedor);
		printf("Vendedor: %s\n",aux->vendedor);
		printf("Total: %.2f",aux->totalProducto);
		printf("\tTiempo de atencion: %d min.",aux->tiempoAtencion);
        aux = aux->siguiente;
        printf("\n\n");
        i++;
	}
    if (i==0) printf( "\n�La lista esta vacia!\n" );
}

